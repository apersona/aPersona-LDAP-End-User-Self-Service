<?php

# ENSURE YOUR PHP IMPLEMENTATION HAS THE FOLLOWING php.ini SETTINGS:  (Once set of course, PHP sessions will only work for secure connections.)
#  session.cookie_secure = 1
#  session.cookie_httponly = 1
#  session.cookie_lifetime = 1200	(Sets the session max time limit to 20 min.)


# When the login pages loads, we want to ensure all sessions are cleared.
session_start(); # Starts the session

session_unset(); #removes all the variables in the session
session_destroy(); #destroys the session
if ( session_id() == "" ) { @session_start(); session_regenerate_id();}

# When the user clicks Signin, control is passed to the ss_login script. We need to enable it for it to work.
# If ss_login is not enabled/allowed, it will return back to the home page with an error message.
$_SESSION['allow_ss_login'] = "yes";
# Load Application Branding.
$_SESSION['allow_application_branding'] = "yes";
include_once('../branding/application_branding.php');
$_SESSION['allow_ldap_properties'] = "yes";
include_once('../asm_api/ldap_properties.php');
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Sign in</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- meta name="viewport" content="width=device-width, user-scalable=no" -->
<meta name="viewport" content="width=device-width, initial-scale=.9">


<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: white;
   color: grey;
   text-align: center;
   font-size: 12px;
}
</style>

<style>
p.ex2 {
  margin-left: 8px;
}
</style>


<script type="text/javascript" src="../Login/jquery.js"></script>
<script type="text/javascript" src="../Login/jquery-ui.js"></script>
<script type="text/javascript" src="../Login/polyfiller.js"></script>

<!-- aPersona Client Discovery Script. This generates the aPersona authParam hidden variable. -->
<script type="text/javascript" src="../asm_api/sha1.js"></script>
<script type="text/javascript" src="../asm_api/apersona_v2.3.js"></script>
<!-- End aPersona integration section -->

<script>
  setTimeout(function(){
    document.getElementById('info-message').style.display = 'none';
    /* or
    var item = document.getElementById('info-message')
    item.parentNode.removeChild(item); 
    */
  }, 12000);
</script>


<link rel="stylesheet" type="text/css" href="../fusion.css">
<link rel="stylesheet" type="text/css" href="../style.css">
<link rel="stylesheet" type="text/css" href="../site.css">
</head>
<body style="background-color: rgb(255,255,255); background-image: none; margin: 0px;" class="nof-centerBody">
  <div align="center">
    <table border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td width="3022">
                <table id="Table7" border="0" cellspacing="0" cellpadding="0" width="100%" style="background-color: rgb(245,243,241); height: 54px;">
                  <tr style="height: 54px;">
                    <td width="43" id="Cell288"></td>
                    <td width="2801" id="Cell289">
                      <p class="ex2" style="margin-bottom: 0px;"><a href="../Login/index.php"><img id="Picture26" height="40" width="201" src="../branding/logo.png" vspace="0" hspace="0" align="top" border="0" alt="logo" title="logo"></p>
                    </td>
                    <td width="96" id="Cell309">
                    </td>
                    <td width="18" id="Cell310"></td>
                    <td width="64"  id="Cell311">
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td height="9"></td>
            </tr>
            <tr valign="top" align="left">
              <td width="3023">
                <table id="Table6" border="0" cellspacing="2" cellpadding="2" width="100%" style="height: 106px;">
                  <tr style="height: 110px;">
                    <td width="41" id="Cell150">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                    <td width="98%" id="Cell152">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td align="center">
                            <table id="Table11" border="0" cellspacing="0" cellpadding="0" width="11" style="height: 85px;">
                              <tr style="height: 34px;">
                                <td width="9" id="Cell163">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td width="342" id="Cell290">
                                  <p style="margin-bottom: 0px;"><b><span style="font-size: 28px; font-weight: bold;"><?php echo $_SESSION['company_name'];?></span></b></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell164">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td align="left" id="Cell291">
                                  <p style="margin-bottom: 0px;"><b><span style="font-weight: bold;">&nbsp;<?php echo $_SESSION['app_title'];?></span></b></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell165">
                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td align="center"><img id="Picture25" height="6" width="9" src="../branding/450sp.png" border="0" alt="450sp" title="450sp"></td>
                                    </tr>
                                  </table>
                                </td>
                                <td id="Cell292">
                                  <p style="margin-bottom: 0px;"><img id="Picture18" height="7" width="342" src="../branding/450sp.png" vspace="0" hspace="0" align="middle" border="0" alt="450sp" title="450sp">&nbsp;</p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell166">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td align="left" id="Cell301">
                                  <p style="margin-bottom: 0px;"><i>&nbsp;<?php echo $_SESSION['login_page_notification'];?></i></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell296">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td id="Cell297">
                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td align="left"><img id="Picture31" height="8" width="342" src="../branding/450spWtLGr.png" border="0" alt="450spWtLGr" title="450spWtLGr"></td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td width="25" id="Cell153">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td width="3023">
                <table id="Table8" border="0" cellspacing="0" cellpadding="0" width="100%" style="height: 267px;">
                  <tr style="height: auto;">
                    <td width="41" id="Cell298">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                    <td width="98%" id="Cell299">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td align="center">
                            <form name="SignIn"  method="post" target='_self' action='../scripts/ss_login.php'>
				<!-- aPersona hidden variable authParam passed as a post variable. -->
				<input type="hidden" id="authParam" name="authParam"/>
				<!-- End aPersona integration section -->
                              <table border="0" cellspacing="0" cellpadding="0">
                                <tr valign="top" align="left">
                                  <td width="348">
                                    <table id="SignIn" border="0" cellspacing="0" cellpadding="0" width="99%" style="height: 272px;">
                                      <tr style="height: 19px;">
                                        <td width="23" id="Cell317">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td width="161" id="Cell316">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td width="42" id="Cell315">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td width="24" id="Cell314">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td width="45" id="Cell313">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td width="53" id="Cell312">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                      </tr>
                                      <tr style="height: 26px;">
                                        <td id="Cell167">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="5" valign="middle" id="OrganizationAccount">
                                          <p style="text-align: left; margin-bottom: 0px;"><input type="email" onkeyup="this.value = this.value.toLowerCase()" id="SignInField" name="signin" required class="field required" required="true" size="35" maxlength="40" style="font-size: 20px; white-space: pre; width: 276px;" placeholder="youraccount@example.com" ></p>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell168">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td id="AltEmailCell">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="2" id="not_used_1">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="2" id="not_used_2">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                      </tr>
                                      <tr style="height: 26px;">
                                        <td id="Cell169">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="5" valign="middle" id="Cell270">
                                          <p hidden> <input type="password" ></p><p style="margin-bottom: 0px;"><input type="password" id="txtPassword" name="password" required class="field required" required="true" size="35" maxlength="56" style="font-size: 20px; white-space: pre; width: 276px;" placeholder="Password" autocomplete="new-password"></p>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell170">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="5" style="background-color: rgb(255,255,255);" id="not_used_3">
                                          <p style="text-align: left; margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                      </tr>
                                      <tr style="height: 27px;">
                                        <td id="Cell171">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td valign="middle" style="background-color: rgb(255,255,255);" id="SignIn">
                                          <p style="margin-bottom: 0px;"><input type="image" id="SignInButton" name="LoginButton" src="../branding/signin_button.png" value="Sign in" style="height: 40px; width: 95px;"></p></br>
                                        </td>
                                        <td colspan="2" style="background-color: rgb(255,255,255);" id="not_used_4">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="2" style="background-color: rgb(255,255,255);" id="not_used_5">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell172">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="5" valign="middle" id="Cell275">
                                          <p style="margin-bottom: 0px;"><b><p style="margin-bottom: 0px;"><p id="info-message"><span style="font-size: 14px; color: rgb(159,41,41);"><?php if(strpos($_GET['error'],"<?php")  ||  strpos($_GET['msg'],"<?php")) {header('Location: ../Login/index.php?error=Application violation.'); exit();} ?><?php $error = $_GET['error']; echo($error);?><span style="font-size: 14px; color: rgb(46,139,87);"><?php $msg = $_GET['msg']; echo($msg);?></span></p><b>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell173">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="5" id="not_used_6">
                                          <p style="text-align: left; margin-bottom: 0px;"><b><span style="font-weight: bold;"></span></b>&nbsp;</p>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell174">
                                          <p style="margin-bottom: 0px;"></p>
                                        </td>
                                        <td id="not_used_7">
                                          <p style="text-align: left; margin-bottom: 0px;"><?php if($_SESSION['allow_pwd_reset']=="yes") {echo '<a href="../Reset-Password/reset.php?returnURL=../Login/index.php"><img src="../branding/reset_pwd_button.png" height="25" width="135"></a';} ?></p>
                                        </td>
                                        <td colspan="2" id="not_used_8">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="2" id="not_used_9">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell175">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="5" id="Cell280">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell177">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="2" id="not_used_10">
                                          <p style="text-align: left; margin-bottom: 0px;"><b><span style="font-weight: bold;"></span></b>&nbsp;</p>
                                        </td>
                                        <td colspan="2" id="not_used_11">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td id="Cell146">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell178">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="5" id="Cell282">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell179">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="5" valign="middle" id="Cell287">
                                          <p style="margin-bottom: 0px;"><span style="color: rgb(153,51,51);">&nbsp; </span></p>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell180">
                                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                            <tr>
                                              <td align="center"><img id="Picture24" height="6" width="23" src="../branding/450sp.png" border="0" alt="450sp" title="450sp"></td>
                                            </tr>
                                          </table>
                                        </td>
                                        <td colspan="5" valign="middle" id="Cell162">
                                          <p style="margin-bottom: 0px;"><img id="Picture17" height="7" width="325" src="../branding/450sp.png" vspace="0" hspace="0" align="middle" border="0" alt="450sp" title="450sp">&nbsp;</p>
                                        </td>
                                      </tr>
                                    </table>
                                  </td>
                                </tr>
                              </table>
                            </form>
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td width="25" id="Cell300">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <script type="text/javascript">
          //Begin Webshims
//$.webshims.debug = true;
//$.webshims.activeLang("en");
//$.webshims.setOptions('forms-ext', {replaceUI: false, types: 'datetime-local range date time number month color', widgets: {popover: {appendTo: 'body'}}});
//$.webshims.polyfill('forms forms-ext');
//End Webshims


          </script>
          <div class="footer">
  <p><?php echo $_SESSION['footer']; ?> </p>
</div>

        </td>
      </tr>
    </table>
  </div>
</body>


</html>
 