<?php

# aPersona ASM LDAP Self Service Identity Managment.
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>About</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- meta name="viewport" content="width=device-width, user-scalable=no" -->
<meta name="viewport" content="width=device-width, initial-scale=.9">
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: white;
   color: grey;
   text-align: center;
   font-size: 12px;
}
</style>

<style>
p.ex2 {
  margin-left: 8px;
}
</style>

<script type="text/javascript" src="../Login/jquery.js"></script>
<script type="text/javascript" src="../Login/jquery-ui.js"></script>
<script type="text/javascript" src="../Login/polyfiller.js"></script>

<script>
  setTimeout(function(){
    document.getElementById('info-message').style.display = 'none';
    /* or
    var item = document.getElementById('info-message')
    item.parentNode.removeChild(item); 
    */
  }, 5000);
</script>


<link rel="stylesheet" type="text/css" href="../fusion.css">
<link rel="stylesheet" type="text/css" href="../style.css">
<link rel="stylesheet" type="text/css" href="../site.css">
</head>
<body style="background-color: rgb(255,255,255); background-image: none; margin: 0px;" class="nof-centerBody">
  <div align="center">
    <table border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td width="3022">
                <table id="Table7" border="0" cellspacing="0" cellpadding="0" width="100%" style="background-color: rgb(245,243,241); height: 54px;">
                  <tr style="height: 54px;">
                    <td width="43" id="Cell288"></td>
                    <td width="2801" id="Cell289">
                      <p class="ex2" style="margin-bottom: 0px;"><a href="../Login/index.php"><img id="Picture26" height="40" width="201" src="../branding/logo.png" vspace="0" hspace="0" align="top" border="0" alt="logo" title="logo"></p>
                    </td>
                    <td width="96" id="Cell309">
                    </td>
                    <td width="18" id="Cell310"></td>
                    <td width="64"  id="Cell311">
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td height="9"></td>
            </tr>
            <tr valign="top" align="left">
              <td width="3023">
                <table id="Table6" border="0" cellspacing="2" cellpadding="2" width="100%" style="height: 106px;">
                  <tr style="height: 110px;">
                    <td width="41" id="Cell150">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                    <td width="98%" id="Cell152">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td align="center">
                            <table id="Table11" border="0" cellspacing="0" cellpadding="0" width="11" style="height: 85px;">
                              <tr style="height: 34px;">
                                <td width="9" id="Cell163">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td width="342" id="Cell290">
                                  <p style="margin-bottom: 0px;"><b><span style="font-size: 28px; font-weight: bold;"><?php echo $_SESSION['company_name'];?></span></b></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell164">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td align="left" id="Cell291">
                                  <p style="margin-bottom: 0px;"><br><b><span style="font-size:10px";><?php echo $_SESSION['about'];?></span></b></p>
				  <p style="margin-bottom: 0px;"><br><b><span style="font-size:10px";>
<br>Copyright 2019  -  aPersona, Inc.<br><br>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at<br><br>
<b><a href="http://www.apache.org/licenses/LICENSE-2.0" target="_blank" style="color:black">http://www.apache.org/licenses/LICENSE-2.0</a></b>
<br><br>
Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
<br><br>
<font size="2"><a href="../Login/index.php" style="color:grey">Retrun to login page.</a></font>
				  </p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell165">
                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td align="center"><img id="Picture25" height="6" width="9" src="../branding/450sp.png" border="0" alt="450sp" title="450sp"></td>
                                    </tr>
                                  </table>
                                </td>
                                <td id="Cell292">
                                  <p style="margin-bottom: 0px;"><img id="Picture18" height="7" width="342" src="../branding/450sp.png" vspace="0" hspace="0" align="middle" border="0" alt="450sp" title="450sp">&nbsp;</p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell166">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td align="left" id="Cell301">
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell296">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td id="Cell297">
                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td align="left"><img id="Picture31" height="8" width="342" src="../branding/450spWtLGr.png" border="0" alt="450spWtLGr" title="450spWtLGr"></td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td width="25" id="Cell153">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td width="3023">
                <table id="Table8" border="0" cellspacing="0" cellpadding="0" width="100%" style="height: 267px;">
                  <tr style="height: auto;">
                    <td width="41" id="Cell298">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                    <td width="98%" id="Cell299">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td align="center">

                          </td>
                        </tr>
                      </table>
                    </td>
                    <td width="25" id="Cell300">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <script type="text/javascript">
          //Begin Webshims
//$.webshims.debug = true;
//$.webshims.activeLang("en");
//$.webshims.setOptions('forms-ext', {replaceUI: false, types: 'datetime-local range date time number month color', widgets: {popover: {appendTo: 'body'}}});
//$.webshims.polyfill('forms forms-ext');
//End Webshims


          </script>
          <div class="footer">
  <p><?php echo $_SESSION['footer']; ?> </p>
</div>

        </td>
      </tr>
    </table>
  </div>
</body>
</html>
 