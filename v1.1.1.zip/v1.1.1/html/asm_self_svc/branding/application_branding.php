<?php
ob_start();
@session_start();
IF ($_SESSION['allow_application_branding'] != "yes"){header('Location: ../Login/index.php?error=App branding not allowed.'); exit();}
$_SESSION['allow_application_branding'] = "no";

# Pull the core application folder settings, then access the settings from the specified locations.
$ini_array = parse_ini_file("../asm_api/.application_setup.ini");
$branding_file=$ini_array['apersona_asm_id_mgmt_branding_ini_file'];
$ini_array = parse_ini_file($branding_file);

# Logo link.
# Background color for top bar.
# Sign out image link.
# Background color for Initials
# Text color for Initials

# Company Name and Application Title:
$_SESSION['company_name'] = $ini_array['company_name'];
$_SESSION['app_title'] = $ini_array['app_title'];

# Notification messages for each of the initial "starting" pages: (Text just below the application title text on each page.)
$_SESSION['login_page_notification'] = $ini_array['login_page_notification'];	
$_SESSION['reset_pwd_page_notification'] = $ini_array['reset_pwd_page_notification'];	
$_SESSION['verify_page_notification'] = $ini_array['verify_page_notification'];			


# Verify page instruction branding elements.
$_SESSION['verify_page_org_email_instructions_1'] = $ini_array['verify_page_org_email_instructions_1'];
$_SESSION['verify_page_org_email_instructions_2'] = $ini_array['verify_page_org_email_instructions_2'];

$_SESSION['verify_page_alt_email_instructions_1'] = $ini_array['verify_page_alt_email_instructions_1'];
$_SESSION['verify_page_alt_email_instructions_2'] = $ini_array['verify_page_alt_email_instructions_2'];

$_SESSION['verify_page_mobile_instructions_1'] = $ini_array['verify_page_mobile_instructions_1'];
$_SESSION['verify_page_mobile_instructions_2'] = $ini_array['verify_page_mobile_instructions_2'];

$_SESSION['verify_page_voice_instructions_1'] = $ini_array['verify_page_voice_instructions_1'];
$_SESSION['verify_page_voice_instructions_2'] = $ini_array['verify_page_voice_instructions_2'];


# Identity Mgmt Branding:
$_SESSION['id_mgmt_notification'] = $ini_array['id_mgmt_notification'];
$_SESSION['method_not_set_label'] = $ini_array['method_not_set_label'];

# Branding elements for the Mgmt Portal update pages.
$_SESSION['update_alt_email_instructions'] = $ini_array['update_alt_email_instructions'];
$_SESSION['update_mobile_instructions'] = $ini_array['update_mobile_instructions'];
$_SESSION['update_voice_instructions'] = $ini_array['update_voice_instructions'];
$_SESSION['update_password_instructions'] = $ini_array['update_password_instructions'];

# Branding elements for the Mgmt Portal remove pages.
$_SESSION['remove_alt_email_instructions'] = $ini_array['remove_alt_email_instructions'];
$_SESSION['remove_mobile_instructions'] = $ini_array['remove_mobile_instructions'];
$_SESSION['remove_voice_instructions'] = $ini_array['remove_voice_instructions'];


$ini_array = parse_ini_file("../asm_api/.application_setup.ini");
$copyright_version_file=$ini_array['apersona_copyright_version_ini_file'];
$ini_array = parse_ini_file($copyright_version_file);

# About Page - License
$_SESSION['about']=$ini_array['about'];

# Needs Footer Copyrite text.
$_SESSION['footer']=$ini_array['footer'];

?>