<?php
ob_start();
@session_start();

IF ($_SESSION['allow_ss_reset'] != "yes"){header('Location: ../Reset-Password/reset.php?error=ss_reset: Reset not permitted.'); exit();}
$_SESSION['allow_ss_reset'] = "no";

$_SESSION['allow_ldap_properties'] = "yes";
include_once('../asm_api/ldap_properties.php');

# include_once Logger
$_SESSION['allow_logger'] = "yes";
include_once('../scripts/logger.php');

# Older browsers, check to ensure id entered is in an email format.
if (!filter_var($_POST['signin'], FILTER_VALIDATE_EMAIL)) {header('Location: ../Reset-Password/reset.php?error=Organizational account must be in an email format.'); exit();}

# Load in the ldap properties. check to ensure password reset is allowed.
IF ($_SESSION['allow_pwd_reset']!= "yes"){header('Location: ../Reset-Password/reset.php?error=Reset not enabled!!!!!.'); exit();}

# Set the state of the program into a 'reset password state'. Routing through the programs controllers will depend on this.
$_SESSION['password_reset_state']="yes";

# Pull the user's email login from the Password Reset Page.
$ldap_email = strtolower($_POST['signin']);
$_SESSION['ldap_email'] = strtolower($_POST['signin']);

# Let's verify if the account exists.
$_SESSION['allow_ldap_connection'] = "yes";
include_once('../asm_api/ldap_connection_properties.php');

$_SESSION['allow_ldap_search'] = "yes";
include_once('../scripts/ldap_search.php');
get_ldap_info($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_email'],$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);

$_SESSION['allow_ldap_pad'] = "yes";
include_once('../scripts/ldap_pad.php');

// Return to the reset page if we were not able to find the user that is trying to login.
IF ($_SESSION['valid_user'] != "yes"){write_log(400, "Password Reset: ss_reset - Account not found."); header('Location: ../Reset-Password/reset.php?error=This user or domain is not a valid entry. <br>If you need help, contact support.'); exit();}

// Return to the reset page if the Risk Group is not allowed to use the reset service.
if(preg_match("/{$_SESSION["ldap_risk"]}/i", $disallow_pwd_reset_groups)) {header('Location: ../Reset-Password/reset.php?error=Your security group is not allowed to reset passwords.'); exit();}

# Let's setup the min and max verifications for pwd reset. We simply copy the reset values to the standard login values.
if ($_SESSION['skip_org_email_reset_verification']=="yes") $_SESSION['require_org_email_verification']="no"; else $_SESSION['require_org_email_verification']="yes";
$_SESSION['suadmin_min_verifications']=	$_SESSION['suadmin_min_reset_verifications'];
$_SESSION['high_min_verifications']=	$_SESSION['high_min_reset_verifications'];
$_SESSION['normal_min_verifications']=	$_SESSION['normal_min_reset_verifications'];
$_SESSION['default_min_verifications']=	$_SESSION['default_min_reset_verifications'];
	
$_SESSION['suadmin_max_verifications']=	$_SESSION['suadmin_max_reset_verifications'];
$_SESSION['high_max_verifications']=	$_SESSION['high_max_reset_verifications'];
$_SESSION['normal_max_verifications']=	$_SESSION['normal_max_reset_verifications'];
$_SESSION['default_max_verifications']=	$_SESSION['default_max_reset_verifications'];

# aPersona include_once to setup the url for the aPersona ASM and the API Key.
$_SESSION['allow_apersona_api_properties'] = "yes";
include_once('../asm_api/apersona_api.properties.php');
# End aPersona Integration Code Section 


# Pull in the aPersona Initial Verification Script. We use it for both Login and Password Resets.
$_SESSION['allow_ss_initial_verify'] = "yes";

include_once('../scripts/ss_initial_ap_verification.php');

?>