
<?php

ob_start();
@session_start();
# include_once Logger
$_SESSION['allow_logger'] = "yes";
include_once('../scripts/logger.php');

IF($_SESSION['password_reset_state']=="yes") IF ($_SESSION['allow_ss_initial_verify'] != "yes"){write_log(400, "Password Reset: ss_initial_ap_verification script failed initial state test."); header('Location: ../Reset-Password/reset.php?error=aP execution not permitted.'); exit();}
IF ($_SESSION['allow_ss_initial_verify'] != "yes"){write_log(400, "Id Mgmt: ss_initial_ap_verification script failed initial state test."); header('Location: ../Login/index.php?error=aP execution not permitted.'); exit();}
$_SESSION['allow_ss_initial_verify'] = "no";

// Return to the home page if the user does not have enough available OTP verification channels available based on the settings.
# Pull the minimum number of verifications needed for login based on the risk group.
if($_SESSION["ldap_risk"]=='suadmin') {$_SESSION['reqd_verifications'] = $_SESSION['suadmin_min_verifications'];} 
else {if($_SESSION["ldap_risk"]=='high') {$_SESSION['reqd_verifications'] = $_SESSION['high_min_verifications'];} 
else {if($_SESSION["ldap_risk"]=='normal') {$_SESSION['reqd_verifications'] = $_SESSION['normal_min_verifications'];} 
else {$_SESSION['reqd_verifications'] = $_SESSION['default_min_verifications'];} }}

# Pull the maximum number of verifications needed for login based on the risk group.
if($_SESSION["ldap_risk"]=='suadmin') {$_SESSION['reqd_max_verifications'] = $_SESSION['suadmin_max_verifications'];} 
else {if($_SESSION["ldap_risk"]=='high') {$_SESSION['reqd_max_verifications'] = $_SESSION['high_max_verifications'];} 
else {if($_SESSION["ldap_risk"]=='normal') {$_SESSION['reqd_max_verifications'] = $_SESSION['normal_max_verifications'];} 
else {$_SESSION['reqd_max_verifications'] = $_SESSION['default_max_verifications'];} }}

# Ensure the Required Verification values are within limits.
if($_SESSION['reqd_verifications']<1) $_SESSION['reqd_verifications'] =1; else if($_SESSION['reqd_verifications']>4) $_SESSION['reqd_verifications'] =4;
if($_SESSION['reqd_max_verifications']<$_SESSION['reqd_verifications']) $_SESSION['reqd_max_verifications'] =  $_SESSION['reqd_verifications']; else if($_SESSION['reqd_max_verifications']>4) $_SESSION['reqd_max_verifications'] = 4;

# At this point, we have our min and max values, we can tell if the user can login or not.
# First let's check if password reset users can continue.
if($_SESSION['password_reset_state']=="yes") 
 { 
  # WE NEED TO CHECK IF THE USER HAS ENOUGH METHIDS TO COMPLETE THIS!!!! If we are skipping org email, then we need to decrease the number of available channels by one.
  if ($_SESSION['skip_org_email_reset_verification']=="yes") 
	{
    	 # Reduce the number of available channels by 1.
    	 $_SESSION["number_of_avail_otp_channels"]--;
         if($_SESSION["number_of_avail_otp_channels"] < $_SESSION['reqd_verifications']) {header('Location: ../Reset-Password/reset.php?error=You do not have enough available verification channels to reset your password. <br>Contact support.'); 
	 exit();}
        }
  if($_SESSION['reqd_max_verifications']< $_SESSION["number_of_avail_otp_channels"]) {$_SESSION['reqd_verifications']=$_SESSION['reqd_max_verifications'];}  else {$_SESSION['reqd_verifications'] = $_SESSION["number_of_avail_otp_channels"];}
 }

# If we are not in a password reset case, then here we check to see if the user can login to the Mgmt Service.
if($_SESSION["number_of_avail_otp_channels"] < $_SESSION['reqd_verifications']) 
	{
	 header('Location: ../Login/index.php?error=You do not have enough available verification channels to login. <br>Contact support.'); 
	 exit();
	}

# If the user can login, here we calculate how many verifications they need to login.
if($_SESSION['reqd_max_verifications']< $_SESSION["number_of_avail_otp_channels"]) { $_SESSION['reqd_verifications']=$_SESSION['reqd_max_verifications'];} else {$_SESSION['reqd_verifications'] = $_SESSION["number_of_avail_otp_channels"];}

// Execute an aPersona verification
# retrive authParam from the login page.
$authParam = $_POST['authParam'];
# Run client IP discovery
 $_SESSION['allow_ip_discovery'] = "yes";
 include_once('../asm_api/ap_ip_discovery.php');
 $_SESSION['initial_ip']=$client_ipaddress;

# Pull the domain and save it. Format pulled: 'svc.domain.com:port'. aPersona utilizes the domain of the service in a variety of ways.
 $ap_domain_name = $_SERVER['HTTP_HOST'];

# Set the OTP Pause to 1, since at this point we don't want an OTP to be sent to the user.
$ap_otpp=1;

# Set the OTP Method. Our first otp would be to email if it's sent. So we set otpm = e.
$ap_otpm="e";

# Set the OTP Preference. In this case, we are not sending an OTP, so we set it to null. This variable will be used later and will hold the phone number or alt email address.
$ap_p="";

# Set the Application Host Service Name Label.

$ap_hName = "LDAP Self Service";

# Tell aPersona if it should ignore the device, the network, or both. In this initial login we keep it at 0.
$ap_igd=0;

# Tell aPersona if we want it to auto-regenerate an OTP every time the user requests a resend. This is not at all recommended.
$ap_otpr=0;

# Optional, set OTP Label 3, to a transaction description. In the event an OTP is sent to the user, this label can be appended to the aPersona OTP Email, SMS & Voice descriptions, to provide contextual OTP info to the user.
# For example: "You are about to update your identity verification methods."
if($_SESSION['password_reset_state']=="yes") {$ap_otpud3="You are are attempting a password reset.";} else {$ap_otpud3="You are are logging into LDAP Self Service Portal.";}


#	Here we create the optional (but highly recommended) random key for the aPersona Transaction Integrity ID	
#	This ID is stored in options (opts) variable and reused for otpsend and otpresend scripts.
#	If used, this ID must be reused for downstream associated otpsend and otpresend transacations.
$ap_apti = substr(str_shuffle("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"), 0, 40);

# Set the aPersona Security Policy Forensic Level (1-6) for the initial login verification. This initial verification will provide the following:
# 1) It will tell us if the user is trying to login from an approved country and also that the user is not trying to login from a known threat location.
# 2) It will tell us if the user is able to pass a minimum security check up front. If they can, then we will go ahead and check thier password.
#    If the user cannot pass a minimum security check, then we must perform our user verifications first, before we check the password.
#    Note, regardless of whether or not the user passes this initial security check, the user must still pass 1 or more additional Identity verifications. 

# Set the aPersona API Security Policy Key based on the Risk Group of the user.
 if($_SESSION["ldap_risk"]=='suadmin') {$ap_sec_pol=$suadmin_ap_api_license_key;}
  else {if($_SESSION["ldap_risk"]=='high') {$ap_sec_pol=$high_ap_api_license_key;}
   else {if($_SESSION["ldap_risk"]=='normal') {$ap_sec_pol=$normal_ap_api_license_key;}
    else {$ap_sec_pol=$default_ap_api_license_key;} } }

# Based on the Risk Forensic Level of the user, Set the minimum aPersona Security Level needed for up front password check.
 if($_SESSION["ldap_risk"]=='suadmin') {$ap_sfl=$suadmin_risk_min_level;}
  else {if($_SESSION["ldap_risk"]=='high') {$ap_sfl=$high_risk_min_level;}
   else {if($_SESSION["ldap_risk"]=='normal') {$ap_sfl=$normal_risk_min_level;}
    else {$ap_sfl=$default_risk_min_level;} } }

# execute the initial login apersona verification using the aPersona extAuthenticate API. (In this case we are not branching to any other script or page. Just checking the results.)
# Load the aPersona API function.
# $_SESSION['allow_ap_api_opts_setup'] = "yes";
# include_once('../asm_api/ap_api_opts_setup.php');
 $_SESSION['allow_ap_api'] = "yes";
 include_once('../asm_api/ap_api.php');

# Set the Transaction Type for the aPersona ASM Logs. Specifically we want to note if the user's password was validated.. wait do we know yet?
$ap_ttype="self_svc_login";


# Set all necessary aPersona API Options into Session Variables.
$_SESSION['ap_sec_pol']=$ap_sec_pol; $_SESSION['ldap_email']=$ldap_email; $_SESSION['client_ipaddress']=$client_ipaddress; $_SESSION['ap_sfl']=$ap_sfl; $_SESSION['ap_domain_name']=$ap_domain_name; $_SESSION['authParam']=$authParam; $_SESSION['ap_otpp']=$ap_otpp; $_SESSION['ap_otpm']=$ap_otpm; $_SESSION['ap_ttype']=$ap_ttype; $_SESSION['ap_p']=$ap_p; $_SESSION['ap_hName']=$ap_hName; $_SESSION['ap_igd']=$ap_igd; $_SESSION['ap_otpr']=$ap_otpr; $_SESSION['ap_otpud3']=$ap_otpud3; $_SESSION['ap_apti']=$ap_apti; 

$cookieName = md5(sha1("salt-8nvgt54wo847tyovw8t4nowenh4tc498t".$_SESSION['ap_sec_pol'].$_SESSION['ldap_email'].$_SESSION['ap_domain_name'].$_SESSION["ldap_risk"]));	//Create a hashed cookie name using md5(sha1(salt+id+domain+adminFlag)) 
$_SESSION['cookieName']=$cookieName;
$_SESSION['cookieVal'] = $_COOKIE[$cookieName];	// Pull the current cookie value if it exists. Clearly the first time a user logs in, this will be null.

# Set all the options for the API.
#$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];
# This updated opts includes our new nsf param. "No Saving of Forensics". nsf=1 (check policy and send otp if needed, but do not save forensics if 200-OK.) 
$_SESSION['opts']="nsf=1"."&sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];

# Set the aPersona API Call. In this case we are executing an Authenticate API. (Options are: extAuthenticate.kv?, extVerifyOtp.kv?, extResendOtp.kv?)
$ap_api_service="extAuthenticate.kv?";


#Execute the aPersona API
aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);

# Once we run this first validation, we can move the level back to 7 and the otp pause back to 0 for all the future validations. 
# Set Forensic Level = 7 and update opts.
$_SESSION['ap_sfl'] =7;

	
# Set OTP Pause to 0 and update opts.
$_SESSION['ap_otpp']=0;

# Reset all the opts with the changed values.
$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];


# Even though we will run an initial verification to see if we can check the password up front, this first verification does not require an OTP, so it does not count
# towards that login verification count. So we go ahead here and set it to 0; We also set the User LDAP Password checker to 'no'.
$_SESSION['verifications_passed']=0;
$_SESSION['password_verified']="no";
$_SESSION['otp_channels_used_and_skipped']=0; 
$_SESSION['password_attempt'] = 0;
$_SESSION['verifications_left'] = $_SESSION['reqd_verifications'] - $_SESSION['verifications_passed'];

$_SESSION['channels_left'] = $_SESSION["number_of_avail_otp_channels"] - $_SESSION['otp_channels_used_and_skipped'];
If ($_SESSION['require_org_email_verification']=="yes") {$_SESSION['hide_skip_on_verify_page']="yes";}		// First time verification of Organizational Email, set if we hide the skip method on the verificaiton pages.

# Check the return code and messages, and route accordingly

#	In this next section, we make our decisions on how we handle various ASM Response Codes.
#	echo "aP Return Code= ".$_SESSION['apResp']."<br>";
#	echo "cookieName= ".$_SESSION['cookieName']."<br>";
#       echo "cVal= ".$_SESSION['cVal']."<br>";

# IF we are in a password reset situation, then we want to do some things. 
# 1) If the settings are set to skip the initial organizational email verification (which is the default since most likely the end user won't be able to get to their email if they don't know their password),
# Then we reduce the number of available channels by 1, and increase the number of channels used up. This will effectively skip the Organizational email verification.
# 2) Check to see if the user has enough available channels to reset their password or not.
# or maybe we just skip the code below and just execute our own code 202 here!!
if($_SESSION['password_reset_state']=="yes")
 { 
	$_SESSION['ap_ttype']='self_svc_pwd_reset';
	# Set all the options for the API.
  	if ($_SESSION['skip_org_email_reset_verification']=="yes") 
	{
 	 # If we are not going to send an OTP to the organizational email, then we need to setup the next channel as Alt Email. If the alt email is blank, then we will deal with that in the verify login script.
   	 # Set the number of skipped channels to 1 since we can't use the organizational email.
  	 $_SESSION['otp_channels_used_and_skipped']=1;
 	 $_SESSION['ap_otpm']="ae";
 	 $_SESSION['ap_p']=$_SESSION["ldap_alt_email"];
	 $_SESSION['verify_page_instructions'] = $_SESSION['verify_page_alt_email_instructions_1']." <b><u>".$_SESSION['ae_padded']."</b></u> ".$_SESSION['verify_page_alt_email_instructions_2'];
	} else	
	{
	 $_SESSION['verify_page_instructions'] = $_SESSION['verify_page_org_email_instructions_1']." <b><u>".$_SESSION['e_padded']."</b></u> ".$_SESSION['verify_page_org_email_instructions_2'];
	}
	$_SESSION['ap_otpud3']="You are performing a password reset.";
	$_SESSION['ap_ttype']="Password reset";
	$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];
	# I think we just want to jump to the ss_verify_login script at this point.
	$_SESSION['allow_ss_verify_login'] = "yes";

	#If we are in a password reset situation and the user passes the initial ASM Verification with a 200, then we need to set the cookie.
	switch ($_SESSION['apResp']){
		case 200;
			# "Successful Initial Verification! 
			# Save the OneTimeToken/Cookie set in the aPersona API.
			if ($_SESSION['cVal']!="") setcookie($_SESSION['cookieName'],$_SESSION['cVal'],time()+31536000,null,null,isset($_SERVER["HTTPS"]),TRUE); 	//Set the aPersona Secure (HttpOnly) one-time  use cookie 
		break;
		default:
		}
        #-exit(); 
	header('Location: ../scripts/ss_verify_login.php');
	exit();
  }


switch ($_SESSION['apResp']){
		case 200;
			# "Successful Initial Verification! 
			# Save the OneTimeToken/Cookie set in the aPersona API.
			if ($_SESSION['cVal']!="") setcookie($_SESSION['cookieName'],$_SESSION['cVal'],time()+31536000,null,null,isset($_SERVER["HTTPS"]),TRUE); 	//Set the aPersona Secure (HttpOnly) one-time  use cookie 
			# We can check the user's ID & Password Credentials now.
			$_SESSION['allow_ldap_check_credentials'] = "yes";
			include_once('./ldap_check_credentials.php');
			ldap_login($_SESSION['ldap_email'],$_SESSION['user_ldap_pwd'],$_SESSION['ldap_url']);
			if($_SESSION['login']!=="success") {header('Location: ../Login/index.php?error=Login credential (PWD) problem. Try again.'); exit;}
			$_SESSION['password_verified']="yes";
			# We will run aPersona validations in the following order: 1) organizational account, 2) alt-email, 3) sms/text, 4) voice call.
			$_SESSION['verifications_passed']=0;
			$_SESSION['allow_ss_verify_login'] = "yes";
			header('Location: ./ss_verify_login.php');
			exit();
			
		break;
		case 202;
			# "202 - The aPersona adaptive engine could not initially verify the user. We will not verify the password yet. Instead, we will run a series of OTP Validations.";
			# We will run aPersona validations in the following order: 1) organizational account, 2) alt-email, 3) sms/text, 4) voice call.

			# Setup the apersona variables for the verifications. Since we already have an OTP challenge in the ASM Queue, all we have to do is request it.
			# Set the aPersona API Call. In this case we are executing an extResendOtp.kv API. (Options are: extAuthenticate.kv?, extVerifyOtp.kv?, extResendOtp.kv?)
			# First we need to make a couple of modificaitons to the opts string.
			$_SESSION['ap_ttype']='self_svc_login_pwd_not_yet_validated';
			# Set all the options for the API.
			$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];

			# We are initially sending the OTP to the user's corp email, which is the default. So we don't need to change the otp method like alt-email, or the values for them. Changing these will come later.
			# Setup the aPersona API method. In this case we are resending the OTP that aPersona ASM is holding.
			$ap_api_service="extResendOtp.kv?";

			#Execute the aPersona API
			aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);

			 $_SESSION['allow_verify_page'] = "yes";
			 $_SESSION['verify_page_instructions'] = $_SESSION['verify_page_org_email_instructions_1']." <b><u>".$_SESSION['e_padded']."</b></u> ".$_SESSION['verify_page_org_email_instructions_2'];
			 header('Location: ../Verify/verify.php');
			 exit();
		break;
		case 203;
			# Case 203 - MITM or Country Not allowed, or Bad IP.
			# If we find the user can't pass the country or bad IP Filter, we do not allow them to continue and send them back to the home page.
			header('Location: ../Login/index.php?error=Country or IP not permitted. Contact support.');
		break;
		case 400;
			# Case 400 - User Email was not formatted correctly or a bad request.
			header('Location: ../Login/index.php?error=API Call Error. Contact support.');
		break;
		case 403;
			# Case 403 - Invalid API Svr IP or API Lic Key.
			# Either the API-Lic Key you are using is bad, or the aPersona ASM is not allowing the IP Address of your Server through.
			# Please check your settings to fix the issue.
			header('Location: ../Login/index.php?error=API credential issue. Contact support.');
		break;
		case 404;
			# Case 404 - User is not registered. 
			# Notes: This return code occurs because the aPersona ASM Auto Registration is turned off, and the user has not been 
			# registered for aMFA. If the user is not registered, then we do not let them use the service.
			header('Location: ../Login/index.php?error=You are not registered for Multi-Factor Security. Contact support.');
		break;
		default:
			# There is an unknown error.
			# This default situation is not likely to occur unless your aPersona MFA setup is not working. 
			header('Location: ../Login/index.php?error=We have run into an issue. #s-siav-100'); exit;
}

 exit();


?>