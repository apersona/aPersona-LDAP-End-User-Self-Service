<?php
# aPersona ASM Logger Utility
	# Scripts must include_once the following to run it:
	/*
	# include_once Logger
	# $_SESSION['allow_logger'] = "yes";
	# include_once('./logger.php');
	*/

# Instructions to write to log:		write_log($return_code, "Action");
# Example:  write_log(400, "Id Mgmt: ss_initial_ap_verification script failed initial state test.");
/* Valid Codes: 
	200:	Action completed
	202:	Warning
	300:	Failure
	400:	Possible hack attempt
	500:	Service unavailable
*/


# ob_start();
# @session_start();
IF ($_SESSION['allow_logger'] != "yes"){header('Location: ../Login/index.php?error=logger not permitted.'); exit();}
$_SESSION['allow_logger'] = "no";

function write_log($code, $action) {

#Log File Location
$log = "/var/www/asm_self_svc/asm-id-mgmt.log";
if(!is_file($log)){fopen($log,"w") or die("Unable to open file! Contact support.");}

$date = date('Y-m-d H:i:s');
$user = $_SESSION['ldap_email'];

switch ($code){
		case 200;
		   $code_description="Success.";	
		break;
		case 202;
		   $code_description="Warning.";
		break;
		case 300;
		   $code_description="Failure.";
		break;
		case 400;
		   $code_description="Prevented.";
		break;
		case 500;
		   $code_description="Svc unavailable.";
		break;
		default:
		   $code_description="Unknown error.";
}
	
$session_tag = substr(md5(session_id()."salt-384hj9f8n394gn93u4n98349gnoeirngloskndfplsng"),0,6);

$apti=substr($_SESSION['ap_apti'],0,6);

$logdata="$date  |  "."Session: $session_tag  |  "."ASM APTI: $apti  |  "."$code  |  "."$code_description\t"."$user   \t"."- $action"."\n";

file_put_contents($log, $logdata, FILE_APPEND | LOCK_EX);

fclose($log);
}

?>