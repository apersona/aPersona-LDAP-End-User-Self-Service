<?php
ob_start();
@session_start();
IF ($_SESSION['allow_ss_verify_login'] != "yes"){header('Location: ../Login/index.php?error=Login verification not permitted.'); exit();}
$_SESSION['allow_ss_verify_login'] = "no";
$_SESSION['last_script']="ss_verify_login";

 $_SESSION['allow_ap_api'] = "yes";
 include_once('../asm_api/ap_api.php');

# include_once Logger
 $_SESSION['allow_logger'] = "yes";
 include_once('./logger.php');

# Here we check to see if we have any additional verifications to run. The last time through, the user should end up at the portal.
if($_SESSION['verifications_passed'] <= $_SESSION['reqd_verifications']){
switch ($_SESSION['otp_channels_used_and_skipped']){
	case 0;  // Verify with Corporate-Organizational Email OTP
            # Setup the apersona variables for the verifications. 
	    # Note: aPersona APTI has already been set for this initial verification. No need to change it.
	    # Setup the aPersona API method.
	    $ap_api_service="extAuthenticate.kv?";
	    # During this first login, we are sending the OTP to the user's corp email, which is the default. So we don't need to change the otp method like alt-email, or the values for them.
	    # This first verification defaults to Coporate Email. If the user is unable to get to corporate email, then they will need to reset their password or some other measure.
	    # Execute the aPersona API
		aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);
		switch ($_SESSION['apResp']){
			case 200;
			    # The only way to get to this point is to have an ASM Security Policy in Auto Learning mode which we don't allow.
			    # But in an Auto Learning Mode, ASM remembers user forensics by default, so we want to rerun another aPersona ASM Transaction and tell ASM to Forget the user forensics.
			    $_SESSION['allow_wipe'] = "yes" ; 
			    $_SESSION['ap_ttype']="Auto learning detected, wiping user forensics.";
			    include_once('./wipe.php');
			    $_SESSION['allow_wipe'] = "no"; 
			    write_log(300, "ss_verify_login case 0 - ASM Policy set to auto learn, which is not allowed. Cleared ASM Forensics & sending user back to the login page.");
			    header('Location: ../Login/index.php?error=Auto Learning is not allowed in this application. Contact support.'); exit;
			case 202;
			    $_SESSION['allow_verify_page'] = "yes";
			    $_SESSION['verify_page_instructions'] = $_SESSION['verify_page_org_email_instructions_1']." <b><u>".$_SESSION['e_padded']."</b></u> ".$_SESSION['verify_page_org_email_instructions_2'];
			    if ($_SESSION['apMessage'] == "Error in sending OTP" || $_SESSION['apMessage'] == "No Mobile Route for OTP") {header('Location: ../Verify/verify.php?error=There is a problem sending the identity code to your new number. You may need to contact support.');
			    exit();}
			    else {header('Location: ../Verify/verify.php');
			    exit();}
			break;
			case 203;
				# Case 203 - MITM or Country Not allowed, or Bad IP.
				# If we find the user can't pass the country or bad IP Filter, we do not allow them to continue and send them back to the home page.
				header('Location: ../Login/index.php?error=Country or IP not permitted. Contact support.');
				exit();
			break;
			case 404;
				# Case 404 - User is not registered.
				# Notes: This return code occurs because the aPersona ASM Auto Registration is turned off, and the user has not been 
				# registered for aMFA. If the user is not registered for MFA then we do not let them use the service.
				header('Location: ../Login/index.php?error=You are not registered for Multi-Factor Security. Contact support.');
				exit();
			break;
			default:
			header('Location: ../Login/index.php?error=We have run into an issue. #s-svl-100'); exit;
			}
	break;

	case 1; //  Verification Step 2
	  $_SESSION['hide_skip_on_verify_page']="no";
	  # Note we have to make sure that the Alt-Email is actually available. If not, we need to use SMS next... or voice here in this step.
	  if($_SESSION["ldap_alt_email"]!="") 
	     {# Set opts for alt email and execute api.
		$_SESSION['ap_ttype']="something here - Alt Email Verification."; 
		$_SESSION['ap_otpm']="ae"; 
		$_SESSION['ap_p']=$_SESSION["ldap_alt_email"];
		$_SESSION['verify_page_instructions'] = $_SESSION['verify_page_alt_email_instructions_1']." <b><u>".$_SESSION['ae_padded']."</b></u> ".$_SESSION['verify_page_alt_email_instructions_2'];
		} 
	        else if($_SESSION["ldap_mobile"]!="") {
		# Set opts for mobile and execute api.
		$_SESSION['ap_ttype']="something here - SMS Verification."; 
		$_SESSION['ap_otpm']="s"; 
		$_SESSION['ap_p']=$_SESSION["ldap_mobile"];
		# If p has a '+' in it we need to encode it before we run the aPersona API.
		$_SESSION['ap_p']=str_replace("+", "%2B", $_SESSION['ap_p']); 
		$_SESSION['verify_page_instructions'] = $_SESSION['verify_page_mobile_instructions_1']." <b><u>".$_SESSION['m_padded']."</b></u> ".$_SESSION['verify_page_mobile_instructions_2'];
		} 
	    else if($_SESSION["ldap_voice"]!="") {
		# Set opts for voice and execute api.
		$_SESSION['ap_ttype']="something here - SMS Verification."; 
		$_SESSION['ap_otpm']="v"; 
		$_SESSION['ap_p']=$_SESSION["ldap_voice"];
		# If p has a '+' in it we need to encode it before we run the aPersona API.
		$_SESSION['ap_p']=str_replace("+", "%2B", $_SESSION['ap_p']); 
		$_SESSION['verify_page_instructions'] = $_SESSION['verify_page_voice_instructions_1']." <b><u>".$_SESSION['v_padded']."</b></u> ".$_SESSION['verify_page_voice_instructions_2'];
		} 
	    # Now execute the steps to rerun the aPersona API
		$cookieName = md5(sha1("salt-8nvgt54wo847tyovw8t4nowenh4tc498t".$_SESSION['ap_sec_pol'].$_SESSION['ldap_email'].$_SESSION['ap_domain_name'].$_SESSION["ldap_risk"]));	//Create a hashed cookie name using md5(sha1(salt+id+domain+adminFlag)) 
		$_SESSION['cookieName']=$cookieName;
		$_SESSION['cookieVal'] = $_COOKIE[$cookieName];	// Pull the current cookie value if it exists. Clearly the first time a user logs in, this will be null.

		# Set all the options for the API.
		$_SESSION['ap_apti'] = substr(str_shuffle("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"), 0, 40);
		$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];

		# Set the aPersona API Call. In this case we are executing an Authenticate API. (Options are: extAuthenticate.kv?, extVerifyOtp.kv?, extResendOtp.kv?)
		$ap_api_service="extAuthenticate.kv?";

		#Execute the aPersona API
		aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);
		
		switch ($_SESSION['apResp']){
			case 200;
			    # The only way to get to this point is to have an ASM Security Policy in Auto Learning mode which we don't allow.
			    # But in an Auto Learning Mode, ASM remembers user forensics by default, so we want to rerun another aPersona ASM Transaction and tell ASM to Forget the user forensics.
			    # Set all the options for the API.
		            $_SESSION['ap_igd']=3;	// This tells ASM to forget all forensics associated with the device and network the user is currently using.
			    $_SESSION['ap_otpp']=1;	// We don't want to send out an OTP so we pause it, here just in case.
			    $_SESSION['ap_ttype']="Auto learning detected, wiping user forensics.";
			    $_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];
			    $ap_api_service="extAuthenticate.kv?";
			    aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);
			    write_log(300, "ss_verify_login case 1 - ASM Policy set to auto learn, which is not allowed. Cleared ASM Forensics & sending user back to the login page.");
			    header('Location: ../Login/index.php?error=Auto Learning is not allowed in this application. Contact support.'); exit;
			case 202;
			    $_SESSION['allow_verify_page'] = "yes";
			 if ($_SESSION['apMessage'] == "Error in sending OTP" || $_SESSION['apMessage'] == "No Mobile Route for OTP") {header('Location: ../Verify/verify.php?error=There is a problem sending the identity code to your new number. You may need to contact support.');
			 exit();}
			 else {header('Location: ../Verify/verify.php');
			 exit();}
			    #header('Location: ../Verify/verify.php');
			    #-exit();
			break;
			case 203;
				# Case 203 - MITM or Country Not allowed, or Bad IP.
				# If we find the user can't pass the country or bad IP Filter, we do not allow them to continue and send them back to the home page.
				header('Location: ../Login/index.php?error=Country or IP not permitted. Contact support.');
				exit();
			break;
			case 404;
				# Case 404 - User is not registered.
				# Notes: This return code occurs because the aPersona ASM Auto Registration is turned off, and the user has not been 
				# registered for aMFA. If the user is not registered for MFA, we do not let them use the service.
				# aPersona supports both Opt-In, Opt-Out & Mandatory registrations.
				header('Location: ../Login/index.php?error=You are not registered for Multi-Factor Security. Contact support.');
				exit();
			break;
			default:
			header('Location: ../Login/index.php?error=We have run into an issue. #s-svl-101'); exit;
			}

	break;

	case 2; // Verification Step 3
	  if($_SESSION["ldap_mobile"]!="") {
		# Set opts for mobile and execute apibr>";
		$_SESSION['ap_ttype']="something here - SMS Verification."; 
		$_SESSION['ap_otpm']="s"; 
		$_SESSION['ap_p']=$_SESSION["ldap_mobile"];
		# If p has a '+' in it we need to encode it before we run the aPersona API.
		$_SESSION['ap_p']=str_replace("+", "%2B", $_SESSION['ap_p']);  
		$_SESSION['verify_page_instructions'] = $_SESSION['verify_page_mobile_instructions_1']." <b><u>".$_SESSION['m_padded']."</b></u> ".$_SESSION['verify_page_mobile_instructions_2'];
		} 
	    else if($_SESSION["ldap_voice"]!="") {
		# Set opts for voice and execute api.
		$_SESSION['ap_ttype']="something here - SMS Verification."; 
		$_SESSION['ap_otpm']="v"; 
		$_SESSION['ap_p']=$_SESSION["ldap_voice"];
		# If p has a '+' in it we need to encode it before we run the aPersona API.
		$_SESSION['ap_p']=str_replace("+", "%2B", $_SESSION['ap_p']); 
		$_SESSION['verify_page_instructions'] = $_SESSION['verify_page_voice_instructions_1']." <b><u>".$_SESSION['v_padded']."</b></u> ".$_SESSION['verify_page_voice_instructions_2'];
		} 
	    # Now execute the steps to rerun the aPersona API
		$cookieName = md5(sha1("salt-8nvgt54wo847tyovw8t4nowenh4tc498t".$_SESSION['ap_sec_pol'].$_SESSION['ldap_email'].$_SESSION['ap_domain_name'].$_SESSION["ldap_risk"]));	//Create a hashed cookie name using md5(sha1(salt+id+domain+adminFlag)) 
		$_SESSION['cookieName']=$cookieName;
		$_SESSION['cookieVal'] = $_COOKIE[$cookieName];	// Pull the current cookie value if it exists. Clearly the first time a user logs in, this will be null.

		# Set all the options for the API.
		$_SESSION['ap_apti'] = substr(str_shuffle("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"), 0, 40);
		$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];

		# Set the aPersona API Call. In this case we are executing an Authenticate API. (Options are: extAuthenticate.kv?, extVerifyOtp.kv?, extResendOtp.kv?)
		$ap_api_service="extAuthenticate.kv?";

		#Execute the aPersona API
		aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);
		
		switch ($_SESSION['apResp']){
			case 200;
			    # The only way to get to this point is to have an ASM Security Policy in Auto Learning mode which we don't allow.
			    # But in an Auto Learning Mode, ASM remembers user forensics by default, so we want to rerun another aPersona ASM Transaction and tell ASM to Forget the user forensics.
			    # Set all the options for the API.
		            $_SESSION['ap_igd']=3;	// This tells ASM to forget all forensics associated with the device and network the user is currently using.
			    $_SESSION['ap_otpp']=1;	// We don't want to send out an OTP so we pause it, here just in case.
			    $_SESSION['ap_ttype']="Auto learning detected, wiping user forensics.";
			    $_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];
			    $ap_api_service="extAuthenticate.kv?";
			    aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);
			    write_log(300, "ss_verify_login case 2 - ASM Policy set to auto learn, which is not allowed. Cleared ASM Forensics & sending user back to the login page.");
			    header('Location: ../Login/index.php?error=Auto Learning is not allowed in this application. Contact support.'); exit;
			case 202;
			    $_SESSION['allow_verify_page'] = "yes";
			 if ($_SESSION['apMessage'] == "Error in sending OTP" || $_SESSION['apMessage'] == "No Mobile Route for OTP") {header('Location: ../Verify/verify.php?error=There is a problem sending the identity code to your new number. You may need to contact support.');
			 exit();}
			 else {header('Location: ../Verify/verify.php');
			 exit();}
			    #header('Location: ../Verify/verify.php');
			    #-exit();
			break;
			case 203;
				# Case 203 - MITM or Country Not allowed, or Bad IP.
				# If we find the user can't pass the country or bad IP Filter, we do not allow them to continue and send them back to the home page.
				header('Location: ../Login/index.php?error=Country or IP not permitted. Contact support.');
				exit();
			break;
			case 404;
				# Case 404 - User is not registered.
				# Notes: This return code occurs because the aPersona ASM Auto Registration is turned off, and the user has not been 
				# registered for aMFA. 
				header('Location: ../Login/index.php?error=You are not registered for Multi-Factor Security. Contact support.');
				exit();
			break;
			default:
			header('Location: ../Login/index.php?error=We have run into an issue. #s-svl-102'); exit;
			}
	break;

	case 3; //Verification Step 4
	   if($_SESSION["ldap_voice"]!="") {
		# Set opts for voice and execute api.
		$_SESSION['ap_ttype']="something here - SMS Verification."; 
		$_SESSION['ap_otpm']="v"; 
		$_SESSION['ap_p']=$_SESSION["ldap_voice"];
		# If p has a '+' in it we need to encode it before we run the aPersona API.
		$_SESSION['ap_p']=str_replace("+", "%2B", $_SESSION['ap_p']); 
		$_SESSION['verify_page_instructions'] = $_SESSION['verify_page_voice_instructions_1']." <b><u>".$_SESSION['v_padded']."</b></u> ".$_SESSION['verify_page_voice_instructions_2'];
		} 
	    # Now execute the steps to rerun the aPersona API
		$cookieName = md5(sha1("salt-8nvgt54wo847tyovw8t4nowenh4tc498t".$_SESSION['ap_sec_pol'].$_SESSION['ldap_email'].$_SESSION['ap_domain_name'].$_SESSION["ldap_risk"]));	//Create a hashed cookie name using md5(sha1(salt+id+domain+adminFlag)) 
		$_SESSION['cookieName']=$cookieName;
		$_SESSION['cookieVal'] = $_COOKIE[$cookieName];	// Pull the current cookie value if it exists. Clearly the first time a user logs in, this will be null.

		# Set all the options for the API.
		$_SESSION['ap_apti'] = substr(str_shuffle("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"), 0, 40);
		$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];

		# Set the aPersona API Call. In this case we are executing an Authenticate API. (Options are: extAuthenticate.kv?, extVerifyOtp.kv?, extResendOtp.kv?)
		$ap_api_service="extAuthenticate.kv?";

		#Execute the aPersona API
		aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);
		
		switch ($_SESSION['apResp']){
			case 200;
			    # The only way to get to this point is to have an ASM Security Policy in Auto Learning mode which we don't allow.
			    # But in an Auto Learning Mode, ASM remembers user forensics by default, so we want to rerun another aPersona ASM Transaction and tell ASM to Forget the user forensics.
			    # Set all the options for the API.
		            $_SESSION['ap_igd']=3;	// This tells ASM to forget all forensics associated with the device and network the user is currently using.
			    $_SESSION['ap_otpp']=1;	// We don't want to send out an OTP so we pause it, here just in case.
			    $_SESSION['ap_ttype']="Auto learning detected, wiping user forensics.";
			    $_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];
			    $ap_api_service="extAuthenticate.kv?";
			    aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);
			    write_log(300, "ss_verify_login case 3 - ASM Policy set to auto learn, which is not allowed. Cleared ASM Forensics & sending user back to the login page.");
			    header('Location: ../Login/index.php?error=Auto Learning is not allowed in this application. Contact support.'); exit;
			case 202;
			    $_SESSION['allow_verify_page'] = "yes";
			 if ($_SESSION['apMessage'] == "Error in sending OTP" || $_SESSION['apMessage'] == "No Mobile Route for OTP") {header('Location: ../Verify/verify.php?error=There is a problem sending the identity code to your new number. You may need to contact support.');
			 exit();}
			 else {header('Location: ../Verify/verify.php');
			 exit();}
			    #header('Location: ../Verify/verify.php');
			    #-exit();
			break;
			case 203;
				# Case 203 - MITM or Country Not allowed, or Bad IP.
				# If we find the user can't pass the country or bad IP Filter, we do not allow them to continue and send them back to the home page.
				header('Location: ../Login/index.php?error=Country or IP not permitted. Contact support.');
				exit();
			break;
			case 404;
				# Case 404 - User is not registered.
				# Notes: This return code occurs because the aPersona ASM Auto Registration is turned off, and the user has not been 
				# registered for aMFA. 
				header('Location: ../Login/index.php?error=You are not registered for Multi-Factor Security. Contact support.');
				exit();
			break;
			default:
			header('Location: ../Login/index.php?error=We have run into an issue. #s-svl-103'); exit;
			}
	break;
	case 4; //Verification Step 5
	    header('Location: ../Login/index.php?msg=You have skipped too may options. Try again.'); exit;
	break;
	

	default:
	# There is an unknown error.
	# This default situation is not likely to occur unless your aPersona MFA setup is not working. 
	header('Location: ../Login/index.php?msg=You have skipped too may options. Try again.'); exit;
}
header('Location: ../Login/index.php?msg=You have skipped too may options. Try again.'); exit;
}
header('Location: ../Login/index.php?msg=You have skipped too may options. Try again.'); exit;
?>