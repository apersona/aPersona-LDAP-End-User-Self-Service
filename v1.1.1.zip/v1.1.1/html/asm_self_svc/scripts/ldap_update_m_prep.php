<?php
# Update Mobile Script Preparation

ob_start();
@session_start();
IF ($_SESSION['allow_ldap_update_prep'] != $_SESSION['id_mgmt_session_salt']){header('Location: ../Login/index.php?error=aP LDAP Update Prep Not Allowed.'); exit();}
$_SESSION['allow_ldap_update_prep'] = "no";
if ($_POST['allow_update_prep'] != "yes") {header('Location: ../Login/index.php?error=aP LDAP Update Prep Not Allowed.'); exit();}	// Ensure this script is called from post execution.

if($_SESSION['chgpwd']=='yes') {header('Location: ../ID-Mgmt/id-mgmt.php?msg=You must update your password before any other updates can be made.'); exit();}

$_SESSION['allow_update_page'] = $_SESSION['id_mgmt_session_salt'];
$_SESSION['update_try']=0;

# Setup variables for ldap_update.php. In this case we are setting the update method to "Mobile number".
$_SESSION['input_type']= "tel";
$_SESSION['update_method'] = "Type in your <u>new</u> Country Code & Mobile Number. Then click Update.";
$_SESSION['update_new_method_1'] = "Type in your <u>current</u> Country Code & Mobile Number.";
$_SESSION['update_new_method_2'] = "Type in your <u>new</u> Country Code & Mobile Number. Then click Update.";
$_SESSION['update_method_code'] = "m";

$_SESSION['update_instructions'] =  $_SESSION['update_mobile_instructions'];
$_SESSION['current_placeholder'] = "***".substr($_SESSION['m_padded'],3,3);
$_SESSION['new_placeholder'] = ' xxxxxxxxxx';

if($_SESSION['ldap_mobile']=="") {header('Location: ../Update/update_phones_not_set.php'); exit();} else
{header('Location: ../Update/update_phones.php'); 
exit();}


?>
