<?php
# Update Alt-Email Script Preparation

ob_start();
@session_start();

IF ($_SESSION['allow_reset_pwd_prep'] != "yes"){header('Location: ../Reset-Password/reset.php?error=ldap_reset_pwd_prep: Reset not permitted.'); exit();}
$_SESSION['allow_reset_pwd_prep'] = "no";

$_SESSION['allow_reset_pwd'] = "yes";

$_SESSION['update_try']=0;

# Setup variables for ldap_update.php. In this case we are setting the update method to "Password".
$_SESSION['input_type']= "password";
$_SESSION['update_method'] = "Password";
$_SESSION['update_method_code'] = "pwd";
$_SESSION['update_instructions'] = "Reset your Password.";
$_SESSION['current_placeholder'] = ' yourCurrentPwdHere';
$_SESSION['new_placeholder'] = ' yourNewPwdHere';

header("Location: ../Reset-Password/reset-pwd.php?msg=".$_SESSION['password_rules']); 


exit();



?>
