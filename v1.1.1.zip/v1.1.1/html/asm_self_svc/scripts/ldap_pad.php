<?php

#ob_start();
@session_start();
IF ($_SESSION['allow_ldap_pad'] != "yes"){header('Location: ../Login/index.php?error=aP ldap_pad Not Allowed.'); exit();}
$_SESSION['allow_ldap_pad'] = "no";

# For display we want to mask the phone numbers alt-email and email we display.
$_SESSION['m_padded']="*-**".substr($_SESSION["ldap_mobile"],-2);		#Here we create a padded mobile number for the Verification Page if needed.
$_SESSION['v_padded']="*-**".substr($_SESSION["ldap_voice"],-2);		#Here we create a padded voice number for the Verification Page if needed.

$pos=strpos($_SESSION["ldap_alt_email"],"@");
$ae_id=substr($_SESSION["ldap_alt_email"],0,$pos-1);
$ae_domain = substr($_SESSION["ldap_alt_email"],$pos+1,strlen($_SESSION["ldap_alt_email"]));
$_SESSION['ae_padded']=substr($ae_id,0,2)."***@".substr($ae_domain,0,2)."***".substr($ae_domain,strlen($ae_domain)-2,2);

$pos=strpos($_SESSION["ldap_email"],"@");
$e_id=substr($_SESSION["ldap_email"],0,$pos-1);
$e_domain = substr($_SESSION["ldap_email"],$pos+1,strlen($_SESSION["ldap_email"]));
$_SESSION['e_padded']=substr($e_id,0,2)."***@".substr($e_domain,0,2)."***".substr($e_domain,strlen($e_domain)-2,2);

?>