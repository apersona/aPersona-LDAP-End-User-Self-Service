<?php
ob_start();
@session_start();

IF ($_SESSION['allow_ldap_reset'] != "yes"){header('Location: ../Reset-Password/reset.php?error=ldap_reset_pwd: Reset not permitted.'); exit();}
$_SESSION['allow_ldap_reset'] = "no";

# in this script we will do the following.
# 1. update ldap Password.
# 2. Re-run the get ldap info to reload the latest values in LDAP.
# 3. Put the user back to the mgmt page with a message where they can see their change.

# Connect to LDAP and get user current info.
# Enable the LDAP Connect and Search Scripts for execution & include_once the LDAP Properties file.
$_SESSION['allow_ldap_connection'] = "yes";
include_once('../asm_api/ldap_connection_properties.php');

$_SESSION['allow_ldap_properties'] = "yes";
include_once('../asm_api/ldap_properties.php');

$_SESSION['allow_ldap_search'] = "yes";
include_once('./ldap_search.php');

# check posted 'current' value. Could be alt-email, mobile, voice, or password. Valid methods are: 'ae','s','v','pwd'. 

IF ($_SESSION['update_state']=="pwd") 
	{
	 update_password($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_name'],$_SESSION['new_entry']);
	 get_ldap_info($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_email'],$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);
	 header('Location: ../Login/index.php?msg=Your Password has been updated!'); 
	exit(); }
ELSE
	{header('Location: ../Reset-Password/reset.php?msg=No updates were made.'); exit(); }
	

# Pull the current info from LDAP
get_ldap_info($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_email'],$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);

function update_password($login,$pwd,$url,$ad_name,$newPassword){
//LDAP Bind paramters, need to be an account that can update AD.
$ldap_username = $login;
$ldap_password = $pwd;
$ldap_connection = ldap_connect($url);

// We have to set this option for the version of Active Directory we are using.
ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.

if (TRUE === ldap_bind($ldap_connection, $ldap_username, $ldap_password)){
$prefix = $_SESSION["prefix"];
$postfix = $_SESSION["postfix"];
$dn = "dc=".$prefix.",dc=".$postfix;
$ldap_base_dn = 'CN='.$ad_name.',CN=Users,DC='.$prefix.',DC='.$postfix; 

// create the unicode password
$newPassword = "\"" . $newPassword . "\"";
$len = strlen($newPassword);
for ($i = 0; $i < $len; $i++) $newpass .= "{$newPassword{$i}}\000";
$entry["unicodePwd"] = $newpass;

// Modify the password
if (ldap_mod_replace($ldap_connection, $ldap_base_dn, $entry))
{
  # Successfully updated password.
} else
{
header("Location: ../Update/update.php?error=YOUR PASSWORD WAS NOT UPDATED! Verify password complexity rules and try again. <br> <b>Rules: Can't include_once your ID or Name. Must be 8+ characters. Must include_once 3 of the following: Upper, Lower, Digit, Special Character.</b>"); 
exit();}
}
}

?>