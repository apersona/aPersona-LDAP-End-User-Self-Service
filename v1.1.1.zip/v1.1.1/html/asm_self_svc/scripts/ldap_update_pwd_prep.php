<?php
# Update Alt-Email Script Preparation

ob_start();
@session_start();

IF ($_SESSION['password_reset_state']=="yes") {
	IF ($_POST['allow_update_prep'] != "yes"){header('Location: ../Reset-Password/reset.php?error=aP LDAP Update Prep Not Allowed.'); exit();}
	$_SESSION['allow_ldap_update_prep'] = "no";
	}
	ELSE
	{
	IF ($_SESSION['allow_ldap_update_prep'] != $_SESSION['id_mgmt_session_salt']){header('Location: ../Login/index.php?error=aP LDAP Update Prep Not Allowed.'); exit();}
	$_SESSION['allow_ldap_update_prep'] = "no";
	if ($_POST['allow_update_prep'] != "yes") {header('Location: ../Login/index.php?error=aP LDAP Update Prep Not Allowed.'); exit();}	// Ensure this script is called from post execution.


$_SESSION['allow_update_page'] = $_SESSION['id_mgmt_session_salt'];
$_SESSION['update_try']=0;

# Setup variables for ldap_update.php. In this case we are setting the update method to "Password".
$_SESSION['input_type']= "password";
$_SESSION['update_method'] = "Type your <u>current</u> Password:";
$_SESSION['update_new_method_1'] = "Type your <u>new</u> Password:";
$_SESSION['update_new_method_2'] = "Type your <u>new</u> Password again:";
$_SESSION['update_method_code'] = "pwd";

$_SESSION['update_instructions'] =  $_SESSION['update_password_instructions'];
$_SESSION['current_placeholder'] = ' yourCurrentPwdHere';
$_SESSION['new_placeholder'] = ' yourNewPwdHere';

header("Location: ../Update/update.php?msg=".$_SESSION['password_rules']); 
exit();
}


?>
