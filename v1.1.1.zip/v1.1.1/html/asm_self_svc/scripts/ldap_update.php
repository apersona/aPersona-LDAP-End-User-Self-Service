<?php
ob_start();
@session_start();
if ($_SESSION['id_mgmt_session_salt']==""){header('Location: ../Login/index.php?msg=This session has timed out.'); exit();}
IF ($_SESSION['allow_ldap_update'] != $_SESSION['id_mgmt_session_salt']){header('Location: ../Login/index.php?error=aP LDAP Update Not Allowed.'); exit();}
$_SESSION['allow_ldap_update'] = "no";
if ($_POST['allow_update'] != "yes") {header('Location: ../Login/index.php?error=aP LDAP Update Not Allowed.'); exit();}	// Ensure this script is called from post execution.

# include_once Logger
 $_SESSION['allow_logger'] = "yes";
 include_once('./logger.php');

# Now that the user is logged in, as we reuse the verify page and other scripts used during login, we need to track the update state. If update_state is not null, then the user is logged in and is in the process of updating a value.
# valid values are:  ae, s, v, pwd.
$_SESSION['update_state']="";
$_SESSION['update_state_msg']="";

# Connect to LDAP and get user current info.
# Enable the LDAP Connect and Search Scripts for execution & include_once the LDAP Properties file.
$_SESSION['allow_ldap_connection'] = "yes";
include_once('../asm_api/ldap_connection_properties.php');

$_SESSION['allow_ldap_properties'] = "yes";
include_once('../asm_api/ldap_properties.php');


$_SESSION['allow_ldap_search'] = "yes";
include_once('./ldap_search.php');


$authParam = $_POST['authParam'];
# Run client IP discovery
 $_SESSION['allow_ip_discovery'] = "yes";
 include_once('../asm_api/ap_ip_discovery.php');

# Pull the current One Time Transaction Cookie.
$cookieName = md5(sha1("salt-8nvgt54wo847tyovw8t4nowenh4tc498t".$_SESSION['ap_sec_pol'].$_SESSION['ldap_email'].$_SESSION['ap_domain_name'].$_SESSION["ldap_risk"]));	//Create a hashed cookie name using md5(sha1(salt+id+domain+adminFlag)) 
$_SESSION['cookieName']=$cookieName;
$_SESSION['cookieVal'] = $_COOKIE[$cookieName];

 $_SESSION['allow_ap_api'] = "yes";
 include_once('../asm_api/ap_api.php');

# Pull the current info from LDAP
get_ldap_info($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_email'],$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);


# Make sure all the entries coming in are lower case.
$_POST['current'] = $_POST['current'];
$_POST['new'] = $_POST['new'];
$_POST['new2'] = $_POST['new2'];

$current_phone=$_POST['CurrentCountryCode'].$_POST['current'];
$new_phone=$_POST['NewCountryCode'].$_POST['new'];

switch ($_SESSION['update_method_code']){
		case "ae_remove";
			$_POST['current'] = strtolower($_POST['current']);
			if ($_POST['current'] != $_SESSION["ldap_alt_email"]) {header('Location: ../Update/update_remove.php?error=Your current alt-email does not match, try again.'); exit();} 
			else
			{$_SESSION['new_entry']=" ";
			$_SESSION['update_state']="ae"; 
			$_SESSION['allow_ldap_change'] = $_SESSION['id_mgmt_session_salt'];
			header('Location: ./ldap_change.php');
			exit();
			}
		break;
		case "m_remove";
			if ($current_phone != $_SESSION["ldap_mobile"]) {header('Location: ../Update/update_phones_remove.php?error=Your current mobile number does not match, try again.'); exit();} 
			else
			{$_SESSION['new_entry']=" ";
			$_SESSION['update_state']="m"; 
			$_SESSION['allow_ldap_change'] = $_SESSION['id_mgmt_session_salt'];
			header('Location: ./ldap_change.php');
			exit();
			}
			
		break;
		case "v_remove";
			if ($current_phone != $_SESSION["ldap_voice"]) {header('Location: ../Update/update_phones_remove.php?error=Your current voice number does not match, try again.'); exit();} 
			else
			{$_SESSION['new_entry']=" ";
			$_SESSION['update_state']="v"; 
			$_SESSION['allow_ldap_change'] = $_SESSION['id_mgmt_session_salt'];
			header('Location: ./ldap_change.php');
			exit();
			}			
		break;
		case "ae";
			$_POST['current'] = strtolower($_POST['current']);
			$_POST['new'] = strtolower($_POST['new']);
			$_POST['new2'] = strtolower($_POST['new2']);	
			if ($_POST['current'] != $_SESSION["ldap_alt_email"]) {header('Location: ../Update/update.php?error=Your current alt-email does not match, try again.'); exit();} 
			else if ($_POST['current'] == $_POST['new']) {header('Location: ../Update/update.php?error=New alt-email is the same as current. Try again.'); exit();} 
			else if ($_POST['new'] != $_POST['new2']) {  
									if($_SESSION['ldap_alt_email']=="") {header('Location: ../Update/update_not_set.php?error=New entries are not the same. Try again.'); exit();}
									else 
									{header('Location: ../Update/update.php?error=New entries are not the same. Try again.'); exit();}
								   }
			else
			{
			# Set all the options for the verify.php page.
			$_SESSION['update_state']="ae";
			$_SESSION['verify_page_sub_title'] = "Please verify your new Alt Email.";
			$_SESSION['verify_page_instructions'] = "A one-time identity code has been emailed to your <b>Alt-Email account</b>. Please enter it below and click Verify.";
			# This is the new entry value we will write to LDAP Alt Email Field.
			$_SESSION['new_entry']=$_POST['new'];
			# Set all the options for the API.
			$_SESSION['ap_ttype']='Verify new Alt-Email';
			$_SESSION['ap_otpp']=0;
			$_SESSION['ap_otpud3']="You are about to verify a new Alternate Email Address.";
			$_SESSION['ap_otpm']="ae";
			$_SESSION['ap_sfl']=7;
			$_SESSION['ap_p']=$_POST['new'];
			
			$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];
			$ap_api_service="extAuthenticate.kv?";
			}
		break;
		case "m";	
			if ($current_phone != $_SESSION["ldap_mobile"]) {header('Location: ../Update/update_phones.php?error=Your current mobile number does not match, try again.'); exit();} 
			else if ($current_phone == $new_phone) {header('Location: ../Update/update_phones.php?error=New mobile is the same as current. Try again.'); exit();} 
			else
			{
			# Set all the options for the verify.php page.
			$_SESSION['update_state']="m";
			$_SESSION['verify_page_sub_title'] = "Please verify your new Mobile number.";
			$_SESSION['verify_page_instructions'] = "A one-time identity code has been Texted to your <b>Mobile</b>. Please enter it below and click Verify.";
			# This is the new entry value we will write to LDAP Alt Mobile Field.
			$_SESSION['new_entry']=$new_phone;
			# Set all the options for the API.
			$_SESSION['ap_ttype']='Verify new Mobile';
			$_SESSION['ap_otpp']=0;
			$_SESSION['ap_otpud3']="You are about to verify a new Mobile number.";
			$_SESSION['ap_otpm']="s";
			$_SESSION['ap_sfl']=7;
			$_SESSION['ap_p']=$new_phone;
			$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];
			$ap_api_service="extAuthenticate.kv?";
			}
		break;	
		case "v";		
			if ($current_phone != $_SESSION["ldap_voice"]) {header('Location: ../Update/update_phones.php?error=Your current voice number does not match, try again.'); exit();} 
			else if ($current_phone == $new_phone) {header('Location: ../Update/update_phones.php?error=New voice number is the same as current. Try again.'); exit();} 
			else
			{
			# Set all the options for the verify.php page.
			$_SESSION['update_state']="v";
			$_SESSION['verify_page_sub_title'] = "Please verify your new Voice number.";
			$_SESSION['verify_page_instructions'] = "A one-time identity code is being called to your <b>Voice Number</b>. Please enter it below and click Verify.";
			# This is the new entry value we will write to LDAP Alt Mobile Field.
			$_SESSION['new_entry']=$new_phone;
			# Set all the options for the API.
			$_SESSION['ap_ttype']='Verify new Voice Number';
			$_SESSION['ap_otpp']=0;
			$_SESSION['ap_otpud3']="You are about to verify a new Voice number.";
			$_SESSION['ap_otpm']="v";
			$_SESSION['ap_sfl']=7;
			$_SESSION['ap_p']=$new_phone;
			$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];
			$ap_api_service="extAuthenticate.kv?";
			}
		break;		
		case "pwd";
			# In this case, there is no additional verification needed. We simply need to verify the current password works. Then update ldap with the new password.
			# So we won't drop through this section to the aPersona API verification below.
			# We can check the user's ID & Password Credentials now.
			$_SESSION['allow_ldap_check_credentials'] = "yes";
			include_once('./ldap_check_credentials.php');
			ldap_login($_SESSION['ldap_email'],$_POST['current'],$_SESSION['ldap_url']);
			if($_SESSION['login']!=="success") 
				{
				 $_SESSION['password_attempt']++;
				 if ($_SESSION['password_attempt'] >= $_SESSION['password_attempt_max_tries']) { write_log(300, "ldap_change: User took to many tries to upate password. Dumping user back to login."); header("Location: ../Login/index.php?error=You took to many tries on your password update."); 
				       exit(); } else
				     {write_log(202, "ldap_change: User entered the wrong password.");
				      header('Location: ../Update/update.php?error=Your current password you entered was wrong. Try again.'); 
				      exit; }  
				 }
				else if ($_POST['current'] == $_POST['new']) 
					{write_log(202, "ldap_change: User's new password was the same as their current password.");
					 header('Location: ../Update/update.php?error=New password is the same as current. Try again.'); 
					exit();} 
				else if ($_POST['new'] != $_POST['new2']) 
					{write_log(202, "ldap_change: User's new password and retype of password were not the same.");
					 header('Location: ../Update/update.php?error=New password entries are not the same. Try again.'); 
					exit();}
				else
					{ # All the new password details are valid from what we can tell. Next we need to try to update the password.
					  $_SESSION['update_state']="pwd"; 
					  $_SESSION['new_entry']=$_POST['new'];
					  $_SESSION['allow_ldap_change'] = $_SESSION['id_mgmt_session_salt'];
					  header('Location: ./ldap_change.php');
					exit();}
		break;
		default:
			# There is an unknown error.
			# This default situation is not likely to occur unless your aPersona MFA setup is not working. 
			header('Location: ../Login/index.php?error=ss_login - There is a problem (default). Contact support.');
}

#Execute the aPersona API
aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);

# Next we check the return code from ASM. 202 - OTP Sent is the only valid return code. Anything else and we redirect. (ASM Level was a 7)
switch ($_SESSION['apResp']){
		case 200;
			# Case 200 - The user passed the verification automatically, which is not permitted in this case.
			# In this use case, we do not want to set the cookie. In fact, by not setting the cookie, we purposfully break the One Time Token issued from ASM.
			# This is by design. 
			    # The only way to get to this point is to have an ASM Security Policy in Auto Learning mode which we don't allow.
			    # But in an Auto Learning Mode, ASM remembers user forensics by default, so we want to rerun another aPersona ASM Transaction and tell ASM to Forget the user forensics.
			    # Set all the options for the API.
		            $_SESSION['ap_igd']=3;	// This tells ASM to forget all forensics associated with the device and network the user is currently using.
			    $_SESSION['ap_otpp']=1;	// We don't want to send out an OTP so we pause it, here just in case.
			    $_SESSION['ap_ttype']="Auto learning detected, wiping user forensics.";
			    $_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];
			    $ap_api_service="extAuthenticate.kv?";
			    aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);
			    write_log(300, "ldap_update - ASM Policy set to auto learn, which is not allowed. Cleared ASM Forensics & sending user back to the login page.");			
			header('Location: ../Login/index.php?error=Auto Learning is not permitted. Contact Support!');
			exit();
			
		break;
		case 202;
			# Case 202 - We are in an OTP Verify case. Route to verify.php. If no route for mobile, then display that message.
			$_SESSION['allow_verify_page'] = "yes";
			if ($_SESSION['apMessage'] == "Error in sending OTP" || $_SESSION['apMessage'] == "No Mobile Route for OTP") {header('Location: ../Verify/verify.php?error=There is a problem sending the identity code to your new number. You may need to contact support.');
			 exit();}
			 else {header('Location: ../Verify/verify.php');
			 exit();}
		break;
		case 203;
			# Case 203 - MITM or Country Not allowed, or Bad IP. Location is not permitted.
			# If we find the user can't pass the country or bad IP Filter, we do not allow them to continue and send them back to the home page.
			header('Location: ../Login/index.php?error=Country or IP not permitted. Contact support.');
		break;
		case 400;
			# Case 400 - User Email was not formatted correctly or a bad request.
			header('Location: ../Login/index.php?error=API Call Error. Contact support.');
		break;
		case 403;
			# Case 403 - Invalid API Svr IP or API Lic Key.
			# Either the API-Lic Key you are using is bad, or the aPersona ASM is not allowing the IP Address of your Server through.
			header('Location: ../Login/index.php?error=API credential issue. Contact support.');
		break;
		case 404;
			# Case 404 - User is not registered.
			# Notes: This return code occurs because the aPersona ASM Auto Registration is turned off, and the user has not been 
			# registered for aMFA. If the user is not registered for MFA, then we do not let them use the service.
			header('Location: ../Login/index.php?error=User is not Registered for aMFA. Contact support.');
		break;
		default:
			# There is an unknown error.
			# This default situation is not likely to occur unless your aPersona MFA setup is not working. 
			header('Location: ../Login/index.php?error=ss_login - There is a problem (default). Contact support.');
}



exit();


?>