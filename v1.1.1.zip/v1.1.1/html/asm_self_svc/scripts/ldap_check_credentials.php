
<?php

IF ($_SESSION['allow_ldap_check_credentials'] != "yes"){header('Location: ../Login/index.php?error=LDAP check credentials not allowed.'); exit();}
$_SESSION['allow_ldap_check_credentials'] != "no";




function ldap_login($login,$pwd,$url){

// If the user's pwdLastSet = 0, we must set it to -1 so the user can login.
// So we need to pull in the ldap connection details and set it to -1.
if($_SESSION['chgpwd']=="yes") {

	$_SESSION['allow_ldap_connection'] = "yes";
	include('../asm_api/ldap_connection_properties.php');

	$ldap_username = $ldap_login;
	$ldap_password = $ldap_pwd;
	$ldap_connection = ldap_connect($_SESSION['ldap_url']);

	// We have to set this option for the version of Active Directory we are using.
	ldap_set_option($ldap_connection, LDAP_OPT_NETWORK_TIMEOUT, 10);
	ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
	ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
	if (TRUE === ldap_bind($ldap_connection, $ldap_username, $ldap_password)){
		$dn = "dc=".$_SESSION['prefix'].",dc=".$_SESSION['postfix'];
		$ldap_base_dn = 'CN='.$_SESSION["ldap_name"].',CN=Users,DC='.$_SESSION['prefix'].',DC='.$_SESSION['postfix']; 
		$newinfo["pwdlastset"][0]=-1;
		ldap_modify($ldap_connection, $ldap_base_dn, $newinfo); 
		ldap_unbind($ldap_connection); // Clean up after ourselves.
		}

	}


//LDAP Bind paramters, need to be an account that can update AD.
if (($login=="") || ($pwd=="")) {header('Location: ../Login/index.php?msg=ldap_check_credentials: Please fill in your credentials.'); exit();}
$ldap_connection = ldap_connect($url);
// We have to set this option for the version of Active Directory we are using.
ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
if (TRUE === ldap_bind($ldap_connection, $login, $pwd)){
$_SESSION['login'] = "success";
ldap_unbind($ldap_connection); // Clean up after ourselves.
write_log(200, "ldap_check_credentials: Credentials verified.");


} ELSE {
	 $_SESSION['login'] = "failed";
	 write_log(300, "ldap_check_credentials: Credentials failed.");
	}

// If the user's pwdLastSet was changed to -1, we must set it back to 0.
// So we need to pull in the ldap connection details and setup to set it back.
if($_SESSION['chgpwd']=="yes") {

	$_SESSION['allow_ldap_connection'] = "yes";
	include('../asm_api/ldap_connection_properties.php');

	$ldap_username = $ldap_login;
	$ldap_password = $ldap_pwd;
	$ldap_connection = ldap_connect($_SESSION['ldap_url']);

	// We have to set this option for the version of Active Directory we are using.
	ldap_set_option($ldap_connection, LDAP_OPT_NETWORK_TIMEOUT, 10);
	ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
	ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
	if (TRUE === ldap_bind($ldap_connection, $ldap_username, $ldap_password)){
		$dn = "dc=".$_SESSION['prefix'].",dc=".$_SESSION['postfix'];
		$ldap_base_dn = 'CN='.$_SESSION["ldap_name"].',CN=Users,DC='.$_SESSION['prefix'].',DC='.$_SESSION['postfix']; 
		$newinfo["pwdlastset"][0]=0;
		ldap_modify($ldap_connection, $ldap_base_dn, $newinfo); 
		ldap_unbind($ldap_connection); // Clean up after ourselves.
		}

	}


}