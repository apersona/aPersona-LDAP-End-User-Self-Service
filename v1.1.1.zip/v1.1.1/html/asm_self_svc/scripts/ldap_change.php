<?php
ob_start();
@session_start();
if ($_SESSION['id_mgmt_session_salt']==""){header('Location: ../Login/index.php?msg=This session has timed out.'); exit();}
IF ($_SESSION['allow_ldap_change'] != $_SESSION['id_mgmt_session_salt']){header('Location: ../Login/index.php?error=aP LDAP Update Not Allowed.'); exit();}
$_SESSION['allow_ldap_change'] = "no";

# include_once Logger
 $_SESSION['allow_logger'] = "yes";
 include_once('./logger.php');

# Here we run a quick aPersona ASM Verification just to ensure no one is trying to steal the session.
// Execute an aPersona verification
# retrive authParam from the update page.
$authParam = $_POST['authParam'];
# Run client IP discovery
 $_SESSION['allow_ip_discovery'] = "yes";
 include_once('../asm_api/ap_ip_discovery.php');
# Pull the current One Time Transaction Cookie.
$cookieName = md5(sha1("salt-8nvgt54wo847tyovw8t4nowenh4tc498t".$_SESSION['ap_sec_pol'].$_SESSION['ldap_email'].$_SESSION['ap_domain_name'].$_SESSION["ldap_risk"]));	//Create a hashed cookie name using md5(sha1(salt+id+domain+adminFlag)) 
$_SESSION['cookieName']=$cookieName;
$_SESSION['cookieVal'] = $_COOKIE[$cookieName];	// Pull the current cookie value if it exists. Clearly the first time a user logs in, this will be null.
$_SESSION['ap_ttype']="LDAP Write ASM Check - Level: ".$_SESSION['ldap_write_asm_level']; 
$_SESSION['ap_otpp']=1;   // We want to pause the OTP.
$_SESSION['ap_otpud3']="Attempting to upate LDAP.";
$_SESSION['ap_sfl']=$_SESSION['ldap_write_asm_level'];    // aPersona Forensic Level to use just before executing an LDAP Write/Change.
$_SESSION['ap_apti'] = substr(str_shuffle("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"), 0, 40);

# Set all the options for the API. & Append the Identity/OTP from post at the end.
$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam']."&o=".$_POST['IdentityCode'];

$_SESSION['allow_ap_api'] = "yes";
include_once('../asm_api/ap_api.php');
$ap_api_service="extAuthenticate.kv?";
aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);

# Here we review the aPersona ASM Return Code. If the OTP has timed out, then the resend will fail and we need to return the user to the Login Page with an error.
switch ($_SESSION['apResp']){
		case 200;  // The OTP was sent successfully. This counts as a successful verification. 
			# Write-update aPersona ASM Cookie/Token
			# Save the OneTimeToken/Cookie set in the aPersona API.
			if ($_SESSION['cVal']!="") setcookie($_SESSION['cookieName'],$_SESSION['cVal'],time()+31536000,null,null,isset($_SERVER["HTTPS"]),TRUE); 	//Set the aPersona Secure (HttpOnly) one-time  use cookie 
		break;
		default:
			#In our case, if the user does not pass with a 200, then we have a problem!!!!
			header('Location: ../Login/index.php?error=We recieved a verification challenge before updating. Contact support.');
			exit();
		}



# in this script we will do the following.
# 1. update ldap based on the update field (ae, s, v or pwd).
# 2. Re-run the get ldap info to reload the latest values in LDAP.
# 3. Put the user back to the mgmt page with a message where they can see their change.

# Connect to LDAP and get user current info.
# Enable the LDAP Connect and Search Scripts for execution & include_once the LDAP Properties file.
$_SESSION['allow_ldap_connection'] = "yes";
include_once('../asm_api/ldap_connection_properties.php');
$_SESSION['allow_ldap_properties'] = "yes";
include_once('../asm_api/ldap_properties.php');

$_SESSION['allow_ldap_search'] = "yes";
include_once('./ldap_search.php');

#-echo "*********** BEFORE WE RUN get_ldap_info*****************<br>";
# check posted 'current' value. Could be alt-email, mobile, voice, or password. Valid methods are: 'ae','s','v','pwd'. 

# If new update is for Alt-Email, then we are all set to go update, then re-pull current values, then send user back to mgmt page.
IF ($_SESSION['update_state']=="ae") 
	{
	write_ldap_mail($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_name'],$_SESSION['new_entry'],$ldap__alt_email_field);
	# Pull the current info from LDAP
	get_ldap_info($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_email'],$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);
	if($_SESSION['update_method_code']=='ae_remove') {header('Location: ../ID-Mgmt/id-mgmt.php?msg=Alt-Email has been removed'); exit; } else
	{header('Location: ../ID-Mgmt/id-mgmt.php?msg=Alt-Email has been updated!'); 
	exit();}}
ELSE
IF ($_SESSION['update_state']=="m") 
	{# Note: If no voice number is set in LDAP, then when we write the new mobile number, we will also populate the voice number with the mobile number.  We do not do the reciprocal.
	 write_ldap_mobile($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_name'],$_SESSION['new_entry'],$ldap__mobile_field,$ldap__voice_field);
	 get_ldap_info($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_email'],$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);
	if($_SESSION['update_method_code']=='m_remove') {header('Location: ../ID-Mgmt/id-mgmt.php?msg=Your Mobile has been removed.'); exit();} else
	{ header('Location: ../ID-Mgmt/id-mgmt.php?msg=Your Mobile has been updated!'); 
	exit();}}
ELSE
IF ($_SESSION['update_state']=="v") 
	{
	 write_ldap_voice($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_name'],$_SESSION['new_entry'],$ldap__voice_field);
	 get_ldap_info($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_email'],$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);
	if($_SESSION['update_method_code']=='v_remove') {header('Location: ../ID-Mgmt/id-mgmt.php?msg=Your Voice number has been removed.'); exit();} else
	 {header('Location: ../ID-Mgmt/id-mgmt.php?msg=Your Voice Number has been updated!'); 
	exit(); }}
ELSE
IF ($_SESSION['update_state']=="pwd") 
	{
	 update_password($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_name'],$_SESSION['new_entry']);
	 get_ldap_info($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_email'],$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);
	 header('Location: ../Login/index.php?msg=Your Password has been updated. Please manually retype your new password to login again.'); 
	exit(); }
ELSE
	{header('Location: ../ID-Mgmt/id-mgmt.php?msg=No updates were made.'); exit(); }
	

# Pull the current info from LDAP
# Don't think we need this line. Commenting it out.
# get_ldap_info($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_email'],$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);

function write_ldap_mail($login,$pwd,$url,$ad_name,$mail_update,$aeMailField){
//LDAP Bind paramters, need to be an account that can update AD.
$ldap_username = $login;
$ldap_password = $pwd;
$ldap_connection = ldap_connect($url);

// We have to set this option for the version of Active Directory we are using.
ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
if (TRUE === ldap_bind($ldap_connection, $ldap_username, $ldap_password))
  {
        write_log(200, "ldap_change: Alt-Email update: Successful bind to LDAP.");
	$prefix = $_SESSION["prefix"];
	#-echo "prefix= ".$prefix."<br>";
	$postfix = $_SESSION["postfix"];
	$dn = "dc=".$prefix.",dc=".$postfix;
	$ldap_base_dn = 'CN='.$ad_name.',CN=Users,DC='.$prefix.',DC='.$postfix; 

	// Write out a new mail to the user

     	$newinfo[$aeMailField]=$mail_update;
     	ldap_modify($ldap_connection, $ldap_base_dn, $newinfo); 
     	ldap_unbind($ldap_connection); // Clean up after ourselves.
	write_log(200, "ldap_change: Alt-Email written to LDAP.");
  } else
 {
   write_log(300, "ldap_change: Alt-Email was not written to LDAP. No LDAP Bind. Check user credentials | user state | ldap IP | Network:port | Public Cert.");
   header('Location: ../ID-Mgmt/id-mgmt.php?error=The Alt-Email was not updated. No bind to directory. Contact support.'); exit; 
  }
}

function write_ldap_mobile($login,$pwd,$url,$ad_name,$mobile_update,$mobileField,$voiceField){
//LDAP Bind paramters, need to be an account that can update AD.
$ldap_username = $login;
$ldap_password = $pwd;
$ldap_connection = ldap_connect($url);

// We have to set this option for the version of Active Directory we are using.
ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
if (TRUE === ldap_bind($ldap_connection, $ldap_username, $ldap_password))
  {
	write_log(200, "ldap_change: Mobile update: Successful bind to LDAP.");
	$prefix = $_SESSION["prefix"];
	$postfix = $_SESSION["postfix"];
	$dn = "dc=".$prefix.",dc=".$postfix;
	$ldap_base_dn = 'CN='.$ad_name.',CN=Users,DC='.$prefix.',DC='.$postfix; 

	// Write out a new mobile to the user
     	$newinfo[$mobileField]=$mobile_update;
     	ldap_modify($ldap_connection, $ldap_base_dn, $newinfo); 
	write_log(200, "ldap_change: Mobile written to LDAP.");

     	# If the voice field is null, we will go ahead and write the mobile number into the voice field too. We do this in the event a user needs an otp and can't get it via SMS. 
     	if($_SESSION['ldap_voice_set']=="no") {$newinfo[$voiceField]=$mobile_update;
     	ldap_modify($ldap_connection, $ldap_base_dn, $newinfo); 
     	$_SESSION['ldap_voice_set']="yes";
	write_log(200, "ldap_change: Mobile update: Mobile written to Voice because Voice was empty.");}

     	ldap_unbind($ldap_connection); // Clean up after ourselves.
   } else
   {
   write_log(300, "ldap_change: Mobile was not written to LDAP. No LDAP Bind. Check user credentials | user state | ldap IP | Network:port | Public Cert.");
   header('Location: ../ID-Mgmt/id-mgmt.php?error=The Mobile Number was not updated. No bind to directory. Contact support.'); exit; 
   }
}

function write_ldap_voice($login,$pwd,$url,$ad_name,$voice_update,$voiceField){
//LDAP Bind paramters, need to be an account that can update AD.
$ldap_username = $login;
$ldap_password = $pwd;
$ldap_connection = ldap_connect($url);
// We have to set this option for the version of Active Directory we are using.
ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
if (TRUE === ldap_bind($ldap_connection, $ldap_username, $ldap_password))
  {
	write_log(200, "ldap_change: Voice update: Successful bind to LDAP.");
	$prefix = $_SESSION["prefix"];
	$postfix = $_SESSION["postfix"];
	$dn = "dc=".$prefix.",dc=".$postfix;
	$ldap_base_dn = 'CN='.$ad_name.',CN=Users,DC='.$prefix.',DC='.$postfix; 

	// Write out a new voice to the user
     	$newinfo[$voiceField]=$voice_update;
     	ldap_modify($ldap_connection, $ldap_base_dn, $newinfo); 
	ldap_unbind($ldap_connection); // Clean up after ourselves.
	write_log(200, "ldap_change: Voice written to LDAP.");
  } else 
  {
   write_log(300, "ldap_change: Voice number was not written to LDAP. No LDAP Bind. Check user credentials | user state | ldap IP | Network:port | Public Cert.");
   header('Location: ../ID-Mgmt/id-mgmt.php?error=The Voice Number was not updated. No bind to directory. Contact support.'); exit; 
  }
}


function update_password($login,$pwd,$url,$ad_name,$newPassword){
//LDAP Bind paramters, need to be an account that can update AD.
$ldap_username = $login;
$ldap_password = $pwd;
$ldap_connection = ldap_connect($url);

// We have to set this option for the version of Active Directory we are using.
ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
if (TRUE === ldap_bind($ldap_connection, $ldap_username, $ldap_password))
  {
	write_log(200, "ldap_change: Password update: Successful bind to LDAP.");
	$prefix = $_SESSION["prefix"];
	$postfix = $_SESSION["postfix"];
	$dn = "dc=".$prefix.",dc=".$postfix;
	$ldap_base_dn = 'CN='.$ad_name.',CN=Users,DC='.$prefix.',DC='.$postfix; 

	// create the unicode password
	$newPassword = "\"" . $newPassword . "\"";
	$len = strlen($newPassword);
	for ($i = 0; $i < $len; $i++) $newpass .= "{$newPassword{$i}}\000";
	$entry["unicodePwd"] = $newpass;

	// Modify the password
	if (ldap_mod_replace($ldap_connection, $ldap_base_dn, $entry))
	  {
  	     write_log(200, "ldap_change: Password written to LDAP.");
	  } else
  		{
    		 $_SESSION['password_attempt']++;
    		 if ($_SESSION['password_attempt'] >= $_SESSION['password_attempt_max_tries']) 
			{ write_log(300, "ldap_change: User took to many tries to upate password. Dumping user back to login."); header("Location: ../Login/index.php?error=You took to many tries on your password update."); exit();  } 
			 else 
			{ write_log(202, "ldap_change: User's password did not satisfy password rules."); header("Location: ../Update/update.php?error=[Try ".$_SESSION['password_attempt']." of ".$_SESSION['password_attempt_max_tries']."]<br>Your password was not changed. <br>Review the rules.<br>".$_SESSION['password_rules']); 
          		  exit(); }
                 }
  }
}

?>