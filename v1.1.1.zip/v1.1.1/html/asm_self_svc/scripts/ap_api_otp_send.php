<?php
#ob_start();
@session_start();
IF ($_SESSION['allow_ap_api_otp_send'] != "yes"){header('Location: ../Login/index.php?error=aP API OTP Send Not Allowed.'); exit();}
$_SESSION['allow_ap_api_otp_send'] = "no";
$_SESSION['last_script']="ap_api_otp_send";

 $_SESSION['allow_ap_api'] = "yes";
 include_once('../asm_api/ap_api.php');
$ap_api_service="extVerifyOtp.kv?";

# include_once Logger
$_SESSION['allow_logger'] = "yes";
include_once('./logger.php');

# Identity Code Input Validation
if($_POST['IdentityCode']=="") {$_SESSION['allow_verify_page'] = "yes"; header('Location: ../Verify/verify.php?error=Please enter a code.'); exit();}
if(strlen($_POST['IdentityCode']) < 4) {$_SESSION['allow_verify_page'] = "yes"; header('Location: ../Verify/verify.php?error=Code must be at least 4 digits.'); exit();}

# Pull the current One Time Transaction Cookie. (we may not need to do this, but it can't hurt.)
$cookieName = md5(sha1("salt-8nvgt54wo847tyovw8t4nowenh4tc498t".$_SESSION['ap_sec_pol'].$_SESSION['ldap_email'].$_SESSION['ap_domain_name'].$_SESSION["ldap_risk"]));	//Create a hashed cookie name using md5(sha1(salt+id+domain+adminFlag)) 
$_SESSION['cookieName']=$cookieName;
$_SESSION['cookieVal'] = $_COOKIE[$cookieName];	// Pull the current cookie value if it exists. Clearly the first time a user logs in, this will be null.

# Set all the options for the API. & Append the Identity/OTP from post at the end.
$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam']."&o=".$_POST['IdentityCode'];

aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);

# Here we review the aPersona ASM Return Code. If the OTP has timed out, then the resend will fail and we need to return the user to the Login Page with an error.
switch ($_SESSION['apResp']){
		case 200;  // The OTP was sent successfully. This counts as a successful verification. 
			# Write-update aPersona ASM Cookie/Token
			# Save the OneTimeToken/Cookie set in the aPersona API.
			if ($_SESSION['cVal']!="") setcookie($_SESSION['cookieName'],$_SESSION['cVal'],time()+31536000,null,null,isset($_SERVER["HTTPS"]),TRUE); 	//Set the aPersona Secure (HttpOnly) one-time  use cookie 

			# If the user is not in a password reset state, we can check the password at this point. Otherwise we skip it.
			IF ($_SESSION['password_reset_state']!="yes")
			  {
			   # Check Password
			   # If the user has passed the aPersona verification at least one time, we can now check their password.
			   If ($_SESSION['password_verified']!="yes") 
			     {
			     $_SESSION['allow_ldap_check_credentials'] = "yes";
			     include_once('../scripts/ldap_check_credentials.php');
			     ldap_login($_SESSION['ldap_email'],$_SESSION['user_ldap_pwd'],$_SESSION['ldap_url']);
			     if($_SESSION['login']=="success") 
				{ 
				  $_SESSION['password_verified']="yes";} else 
				{
				 header('Location: ../Login/index.php?error=Login credential (PWD) problem. Try again.'); exit();}
			     }
			    }


			# Increase the Verificaiton Counts
			# We need to increase the verification count by one. If we still have more verifications, then we go back and run it again.
			$_SESSION['verifications_passed']++;
			$_SESSION['otp_channels_used_and_skipped']++; 
			$_SESSION['debug']++;
			$_SESSION['channels_left'] = $_SESSION["number_of_avail_otp_channels"] - $_SESSION['otp_channels_used_and_skipped'];
			$_SESSION['verifications_left'] = $_SESSION['reqd_verifications'] - $_SESSION['verifications_passed'];			

			# Check to see if the user has passed enough to continue
			# Here we evaluate if the user has completed enough verifications to login. If not, we go back to the ss_verify_login script and try the next one.
			if($_SESSION['verifications_passed'] < $_SESSION['reqd_verifications'])
			  {$_SESSION['allow_ss_verify_login'] = "yes"; 
			   header('Location: ../scripts/ss_verify_login.php'); 
			   exit(); } 
			else 
			 {
			  # At this point, we have three different use cases to deal with.
			  # 1) User is in a password reset state. If so, we are going to send them to the ldap_reset_pwd_prep.php script to get things setup for the user to enter their new password.
			  # 2) The user is logging in normally to update their identity verification methods (Alt-Email, Mobile, Voice, or Update Pwd.) This case, the user is logged in.
			  # 3) The user has already logged in, and is in the process of updating their Alt-Email, Mobile, Voice. In this case  the logic transfers to the ldap_change.
			  #    Note that the reason for use case #3, is that we use aPersona OTP's to verify the new Alt-Email, Mobile or Voice channels. PWD Updates need no additional verification.
			  # Here we handle use case 1.

			  IF ($_SESSION['password_reset_state']=="yes") {
				$_SESSION['allow_reset_pwd_prep'] = "yes";
				header('Location: ../scripts/ldap_reset_pwd_prep.php'); exit();
				}
			    else
			    {
			     # Here we handle use cases 2 & 3. Setup Session, see if the user should go to the Mgmt portal, or the ldap_change.php script to update their info.
			     # Setup the Logged in state Session.
			     $_SESSION['id_mgmt_session_salt'] = md5(md5(md5(substr(str_shuffle("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"), 0, 40).$_SESSION['ldap_email'])));
			     $_SESSION['allow_id_mgmt_page'] = $_SESSION['id_mgmt_session_salt'];

			     IF ($_SESSION['update_state']=="") {header('Location: ../ID-Mgmt/id-mgmt.php'); exit();} ELSE
			        {# Since the user has just updated some info, we need to transfer to a "ldap_change" script to update LDAP and transfer the user back to the Mgmt page.
			         $_SESSION['allow_ldap_change'] = $_SESSION['id_mgmt_session_salt'];
			         header('Location: ./ldap_change.php');
			         exit();}
			      }
			  }
			header('Location: ../Login/index.php?error=System error. This should not have happened. Server or network problem maybe.');
			exit();
		break;
		case 202;  // The OTP was wrong. Go back to the Verification Page with en error.
			$_SESSION['allow_verify_page'] = "yes";
			if ($_SESSION['apMessage'] == "Error in sending OTP" || $_SESSION['apMessage'] == "No Mobile Route for OTP") {header('Location: ../Verify/verify.php?error=There is a problem sending the identity code to your new number. You may need to contact support.');
			 exit();} else {header('Location: ../Verify/verify.php?error=You entered the wrong code.'); exit();}

			
		break;
		case 401;
			IF ($_SESSION['password_reset_state']=="yes") { header('Location: ../Reset-Password/reset.php?error=Your identity code has expired. Try logging in again.'); exit();} else
			{ header('Location: ../Login/index.php?error=Your identity code has expired. Try logging in again.'); exit();}
		break;
		default:
			# This default situation is not likely to occur unless your aPersona MFA setup is not working. 
			# In our demo, we send the user back to login with an error. In a live setup, you might want to log the user in and work on fixing the issue.
			# header('Location: ../Login/index.php?error=ap_api_otp_send.php - There is a problem (default). Contact support.');
			IF ($_SESSION['password_reset_state']=="yes") { header('Location: ../Reset-Password/reset.php?error=There is a problem (default). Contact support.'); exit();} else { header('Location: ../Login/index.php?error=There is a problem (default). Contact support.'); exit();}

}
exit();


?>