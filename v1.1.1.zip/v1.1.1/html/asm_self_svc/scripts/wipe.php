<?php
# Wipe the user's forensics.
IF ($_SESSION['allow_wipe'] == "yes") {
 $_SESSION['ap_igd']=3;	// This tells ASM to forget all forensics associated with the device and network the user is currently using.
 $_SESSION['ap_otpp']=1;	// We don't want to send out an OTP so we pause it, here just in case.
 $_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam'];
 $ap_api_service="extAuthenticate.kv?";
 aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);
 write_log(300, "Invalid user interaction or user failed to complete a step. Clearing user forensics. Normally after this step the application will send the user back to the login page.");
} else
{header('Location: ../Login/index.php?error=Unauthorized.'); exit();}
?>