<?php
ob_start();
@session_start();
IF ($_SESSION['allow_ss_login'] != "yes"){header('Location: ../Login/index.php?error=Login not permitted.'); exit();}
$_SESSION['allow_ss_login'] = "no";

# Verify user entered their organizational account and password, for older browsers.
If($_POST['signin']==""){header('Location: ../Login/index.php?error=Enter your organizational account please.'); exit();}
if (!filter_var($_POST['signin'], FILTER_VALIDATE_EMAIL)) {header('Location: ../Login/index.php?error=Organizational account must be in an email format.'); exit();}
If($_POST['password']==""){header('Location: ../Login/index.php?error=Enter your organizational password please.'); exit();}

# aPersona include_once to setup the url for the aPersona ASM and the API Key.
$_SESSION['allow_apersona_api_properties'] = "yes";
include_once('../asm_api/apersona_api.properties.php');
# End aPersona Integration Code Section 

# Pull the user's email login and password from the login page.
$ldap_email = strtolower($_POST['signin']);
$_SESSION['ldap_email'] = strtolower($_POST['signin']);
$_SESSION['user_ldap_pwd']= $_POST['password'];
if (($_SESSION['user_ldap_pwd']=="") || ($_SESSION['ldap_email']=="")) {header('Location: ../Login/index.php?msg=ss_login: Please fill in your credentials.'); exit();}


# Connect to LDAP and get their info.
# Enable the LDAP Connect and Search Scripts for execution & include_once the LDAP Properties file.
$_SESSION['allow_ldap_connection'] = "yes";
$_SESSION['allow_ldap_properties'] = "yes";

$_SESSION['allow_ldap_search'] = "yes";

# before we load ldap_properties, we will use the ID & PWD of the user attempting to login to make the connection to LDAP.
# This enables the service to not have to store any ID or PWD locally.

$_SESSION['last_script']="ss_login";
include_once('../asm_api/ldap_connection_properties.php');
include_once('../asm_api/ldap_properties.php');
include_once('./ldap_search.php');

# Do not allow the LDAP Connect user setup in the ldap_properties file to login or use this service.
if($ldap_login==$ldap_email) {header('Location: ../Login/index.php?error=Unauthorized user.'); exit();}
# Connect to LDAP Server & retrieve the details for user: $ldap_email
get_ldap_info($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_email'],$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);
// Now that the ldap pull is completed, shut down the ldap connection script and the ldap search script.
$_SESSION['allow_ldap_connection'] = "no";

# setup user intials for ID Mgmt Page.
$finitial=$_SESSION['ldap_name'][0];
$linitialpos=strrpos($_SESSION['ldap_name'], " ", -0)+1;
$linitial=$_SESSION['ldap_name'][$linitialpos];
$_SESSION['initials']="&nbsp;".$finitial.$linitial."&nbsp;";

// Return to the home page if we were not able to connect to LDAP server.
IF ($_SESSION['valid_ldap_connection'] != "yes"){header('Location: ../Login/index.php?error=Directory service is unavailable. Try again in 15 min.'); exit();}

// Return to the home page if we were not able to find the user that is trying to login.
IF ($_SESSION['valid_user'] != "yes"){header('Location: ../Login/index.php?error=You have a credential issue. User not found.'); exit();}

// Return to the home page if the Risk Group is not allowed to use this service.
if(preg_match("/{$_SESSION["ldap_risk"]}/i", $disallow_login_groups)) {header('Location: ../Login/index.php?error=Your risk level is not allowed to login.'); exit();}

# Pull in the aPersona Initial Verification Script. We use it for both Login and Password Resets.
$_SESSION['allow_ss_initial_verify'] = "yes";
include_once('./ss_initial_ap_verification.php');

?>