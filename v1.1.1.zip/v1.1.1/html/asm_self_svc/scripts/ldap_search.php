
<?php
IF ($_SESSION['allow_ldap_search'] != "yes"){header('Location: ../Login/index.php?error=LDAP search not allowed.'); exit();}
$_SESSION['allow_ldap_search'] != "no";

# include_once Logger
 $_SESSION['allow_logger'] = "yes";
 include_once('./logger.php');

// Main program will call this function with the command below:
// Execute the get_ldap_function
// get_ldap_info($ldap_login,$ldap_pwd,$ldap_url,$ldap_email,$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);

// get_ldap_info function
function get_ldap_info($login,$pwd,$url,$email,$suadmin_risk,$high_risk,$normal_risk,$altemail,$mobile,$voice){
//LDAP Bind paramters, need to be an account that can update AD.
$ldap_username = $login;
$ldap_password = $pwd;
$ldap_connection = ldap_connect($url);
$pos1=strrpos($email,".");
$_SESSION['postfix']=substr($email,$pos1+1);
$partial=substr($email,0,$pos1);
$pos2=strrpos($partial,".");
if($pos2<>0) {$_SESSION['prefix']=substr($partial,$pos2+1);} ELSE 
{ $pos2=strrpos($partial,"@");
  $_SESSION['prefix']=substr($partial,$pos2+1);}

// We have to set this option for the version of Active Directory we are using.
ldap_set_option($ldap_connection, LDAP_OPT_NETWORK_TIMEOUT, 10);
ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
if (TRUE === ldap_bind($ldap_connection, $ldap_username, $ldap_password)){
$dn = "dc=".$_SESSION['prefix'].",dc=".$_SESSION['postfix'];

$filter="(userPrincipalName=$email)";
$justthese = array("name", $altemail, $mobile, $voice, "userAccountControl", "pwdLastSet", "lockoutTime");


$sr=ldap_search($ldap_connection, $dn, $filter, $justthese);
$info = ldap_get_entries($ldap_connection, $sr);

// Check to see if the user exists.
if ($info[0]["name"][0]=='') {$_SESSION['valid_user']="no"; $_SESSION["number_of_avail_otp_channels"] = 0;} 
else {$_SESSION['valid_user']="yes"; 
$_SESSION["number_of_avail_otp_channels"] = 1;


// Search AD for roles/security groups
$ldap__role_search = ldap_search($ldap_connection, $dn,"(userPrincipalName=$email)",array("memberof","primarygroupid"));
$ldap__roles = ldap_get_entries($ldap_connection, $ldap__role_search);
$user_roles=strtolower(json_encode($ldap__roles));
$user_roles=str_replace('cn=',' ',$user_roles);
$user_roles=str_replace('dc=',' ',$user_roles);
$user_roles=str_replace('"',' ',$user_roles);
$user_roles=str_replace(',',' ',$user_roles);
$user_roles=preg_replace('/[^a-zA-Z0-9\s]/', '', $user_roles);

// set user risk initially to "default"
$_SESSION["ldap_risk"] = 'default';

// Is user in normal_risk group?
$role_array_search = explode (",", $normal_risk); 
$length = count($role_array_search);
for($x=0;$x<=$length-1;$x++) { if(preg_match("/($role_array_search[$x])/i", $user_roles)) {$_SESSION["ldap_risk"] = 'normal'; } }

// Is user in high_risk group?
$role_array_search = explode (",", $high_risk); 
$length = count($role_array_search);
for($x=0;$x<=$length-1;$x++) { if(preg_match("/($role_array_search[$x])/i", $user_roles)) {$_SESSION["ldap_risk"] = 'high'; } }

// Is user in suadmin_risk group?
$role_array_search = explode (",", $suadmin_risk); 
$length = count($role_array_search);
for($x=0;$x<=$length-1;$x++) { if(preg_match("/($role_array_search[$x])/i", $user_roles)) { $_SESSION["ldap_risk"] = 'suadmin'; } }

//Retrieve Alt-Email, Mobile and Voice channels & verify them & count the total number of unique channels.
$_SESSION["ldap_name"] = $info[0]["name"][0];
$_SESSION["ldap_alt_email"] = str_replace(' ','',$info[0][$altemail][0]);

if (filter_var($_SESSION["ldap_alt_email"], FILTER_VALIDATE_EMAIL)) {
    $_SESSION["number_of_avail_otp_channels"]++;
} ELSE  $_SESSION["ldap_alt_email"] = "";
if($_SESSION["ldap_alt_email"]==$email) {$_SESSION["ldap_alt_email"] = ""; $_SESSION["number_of_avail_otp_channels"] = 1;}

$tempMobile = preg_replace("/[^0-9]/s", "", $info[0][$mobile][0]);
$tempMobile = "X".$tempMobile;
if (preg_match("/X1|X7|X20|X27|X30|X31|X32|X33|X34|X36|X39|X40|X41|X43|X44|X45|X46|X47|X48|X49|X51|X52|X53|X54|X55|X56|X57|X58|X60|X61|X62|X63|X64|X65|X66|X81|X82|X84|X86|X90|X91|X92|X93|X94|X95|X98|X212|X213|X216|X218|X220|X221|X222|X223|X224|X225|X226|X227|X228|X229|X230|X231|X232|X233|X234|X235|X236|X237|X238|X239|X240|X241|X242|X243|X244|X245|X248|X249|X250|X251|X252|X253|X254|X255|X256|X257|X258|X260|X261|X262|X263|X264|X265|X266|X267|X268|X269|X290|X291|X297|X298|X299|X350|X351|X352|X353|X354|X355|X356|X357|X358|X359|X370|X371|X372|X373|X374|X375|X376|X377|X378|X379|X380|X381|X382|X385|X386|X387|X389|X420|X421|X423|X500|X501|X502|X503|X504|X505|X506|X507|X508|X509|X590|X591|X592|X593|X594|X595|X596|X597|X598|X599|X670|X672|X673|X674|X675|X676|X677|X678|X679|X680|X681|X682|X683|X685|X686|X687|X688|X689|X690|X691|X692|X850|X852|X853|X855|X856|X870|X880|X886|X960|X961|X962|X963|X964|X965|X966|X967|X968|X970|X971|X972|X973|X974|X975|X976|X977|X992|X993|X994|X995|X996|X998/", $tempMobile)) {
    $tempMobile = str_replace("X","+",$tempMobile);
    $_SESSION["number_of_avail_otp_channels"]++;
} else {
    $tempMobile = "";
}
$_SESSION["ldap_mobile"] = $tempMobile;

$tempVoice = preg_replace("/[^0-9]/s", "", $info[0][$voice][0]);
$tempVoice = "X".$tempVoice;
if (preg_match("/X1|X7|X20|X27|X30|X31|X32|X33|X34|X36|X39|X40|X41|X43|X44|X45|X46|X47|X48|X49|X51|X52|X53|X54|X55|X56|X57|X58|X60|X61|X62|X63|X64|X65|X66|X81|X82|X84|X86|X90|X91|X92|X93|X94|X95|X98|X212|X213|X216|X218|X220|X221|X222|X223|X224|X225|X226|X227|X228|X229|X230|X231|X232|X233|X234|X235|X236|X237|X238|X239|X240|X241|X242|X243|X244|X245|X248|X249|X250|X251|X252|X253|X254|X255|X256|X257|X258|X260|X261|X262|X263|X264|X265|X266|X267|X268|X269|X290|X291|X297|X298|X299|X350|X351|X352|X353|X354|X355|X356|X357|X358|X359|X370|X371|X372|X373|X374|X375|X376|X377|X378|X379|X380|X381|X382|X385|X386|X387|X389|X420|X421|X423|X500|X501|X502|X503|X504|X505|X506|X507|X508|X509|X590|X591|X592|X593|X594|X595|X596|X597|X598|X599|X670|X672|X673|X674|X675|X676|X677|X678|X679|X680|X681|X682|X683|X685|X686|X687|X688|X689|X690|X691|X692|X850|X852|X853|X855|X856|X870|X880|X886|X960|X961|X962|X963|X964|X965|X966|X967|X968|X970|X971|X972|X973|X974|X975|X976|X977|X992|X993|X994|X995|X996|X998/", $tempVoice)) {
    $tempVoice = str_replace("X","+",$tempVoice);
    $_SESSION["number_of_avail_otp_channels"]++;
} else 
 {
  $tempVoice = "";
 }
  $_SESSION["ldap_voice"] = $tempVoice;

  // Decrease the Avialable OTP Method Count if both Mobile and Voice numbers are the same.
  if(($_SESSION["ldap_mobile"] != "") && ($_SESSION["ldap_mobile"] == $_SESSION["ldap_voice"])) {$_SESSION["number_of_avail_otp_channels"]--;}

  // If There is a Mobile Number, but not Voice Number, set the Voice Number to be the same as the Mobile Number. We however should not assume that a Voice Number can recieve Texts.. so we don't do the reciprocol.

  if($info[0][$voice][0] == "" || $info[0][$voice][0] == " ") $_SESSION['ldap_voice_set']="no"; else $_SESSION['ldap_voice_set']="yes";
}


// Pull the userAccountControl status.
$ldap_base_dn = 'CN='.$_SESSION["ldap_name"].',CN=Users,DC='.$_SESSION['prefix'].',DC='.$_SESSION['postfix']; 
$_SESSION['userAccountControl'] = $info[0]["useraccountcontrol"][0];
$_SESSION['pwdLastSet'] = $info[0]["pwdlastset"][0];
$_SESSION['lockoutTime'] = $info[0]["lockouttime"][0];
# If the account is NORMAL_ACCOUNT 512 or NORMAL_ACCOUNT | DONT_EXPIRE_PASSWD 66048, then they can use the service. But we check for Forced PWD Reset & Locked Account.
if (($_SESSION['userAccountControl'] == 66048) || ($_SESSION['userAccountControl'] == 512))
	{
	  # Checking to see if Password must be changed.
	  if ( $_SESSION['pwdLastSet'] == 0 ) 
				{
				 # In a password reset situation, the end user may not be able to get to their corporate email. If Admin has allowed skipping, we ensure the end user can skip corp email in this case.
				 if ($_SESSION['allow_skipping_org_email_pwd_reset'] == "yes") $_SESSION['require_org_email_verification'] ="no";

				 $_SESSION['chgpwd']='yes';
				 if ($_SESSION['password_reset_state']=="yes") 
					{ header("Location: ../Login/index.php?msg=Use your temporary password to login, then update your password here. If you don't have a temporary password contact support."); 
	  			          exit();
					}
				}
			# Checking to see if the account is currently locked.
			if ( $_SESSION['lockoutTime'] > 0 )
				{
			    	 write_log(202, "ldap_search - User locked. Sending user back to the login page.");

				 # In an account lock situation, we want to wipe any associated forensics with the current device and network location.	
				  $_SESSION['account_locked']='yes';
				 if ($_SESSION['password_reset_state']=="yes") 
					{ header('Location: ../Reset-Password/reset.php?msg=Account is currently locked. Contact support for more information.'); 
					  exit(); 
					} ELSE
	  			        { header('Location: ../Login/index.php?msg=Account is currently locked. Contact support for more information.'); 
	  			          exit();
					}
				}
	} ELSE
	{
	  // ALL OTHER ACCOUNT TYPES OR ACCOUNTS THAT ARE DISABLED: Cannot use this service.
			write_log(300, "ldap_search - User Disabled or not permitted to use this service. Sending user back to the login page.");
			if ($_SESSION['password_reset_state']=="yes") 
				{ header('Location: ../Reset-Password/reset.php?msg=Your account is either disabled or not permitted to use this service.'); 
				  exit(); 
				} ELSE
	  			{ header('Location: ../Login/index.php?msg=Your account is either disabled or not permitted to use this service.'); 
	  			  exit();
				}
	}


$_SESSION['valid_ldap_connection'] = "yes";
$_SESSION['allow_ldap_pad'] = "yes";
include_once('./ldap_pad.php');

ldap_unbind($ldap_connection); // Clean up after ourselves.
}
ELSE {
       ldap_unbind($ldap_connection); // Clean up after ourselves.
       $_SESSION['valid_ldap_connection'] = "no";
       $_SESSION["number_of_avail_otp_channels"] = 0;
     }
}
?>