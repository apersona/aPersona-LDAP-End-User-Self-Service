<?php
ob_start();
@session_start();
IF ($_SESSION['allow_skip_otp_method'] != "yes"){header('Location: ../Login/index.php?error=Skipping method not allowed.'); exit();}

IF ($_SESSION['require_org_email_verification']=="yes" & $_SESSION['verifications_passed']==0) {header('Location: ../Login/index.php?error=Skipping method not allowed.'); exit();}

$_SESSION['allow_skip_otp_method'] = "no";
$_SESSION['allow_ss_verify_login'] = "yes"; 
$_SESSION['allow_verify_page'] = "yes";
$_SESSION['last_script']="skip_otp_method";
$_SESSION['verifications_left'] = $_SESSION['reqd_verifications'] - $_SESSION['verifications_passed'];

if ($_SESSION['channels_left']-1 >= $_SESSION['verifications_left']) {
$_SESSION['otp_channels_used_and_skipped']++; 
$_SESSION['channels_left'] = $_SESSION["number_of_avail_otp_channels"] - $_SESSION['otp_channels_used_and_skipped'];
header('Location: ../scripts/ss_verify_login.php'); exit();} 
else {
# We can't skip this one!
header("Location: ../Verify/verify.php?error=You can't skip any more and login. Contact support if you are unable to access your identity code."); 
exit();
}

?>
