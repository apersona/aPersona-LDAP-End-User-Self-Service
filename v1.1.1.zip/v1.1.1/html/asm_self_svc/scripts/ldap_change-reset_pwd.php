<?php
ob_start();
@session_start();
IF ($_SESSION['allow_ldap_change-reset_pwd'] != 'yes'){header('Location: ../Reset-Password/reset.php?error=ldap Change-Reset PWd not permitted.'); exit();}
$_SESSION['allow_ldap_change-reset_pwd'] = "no";

# include_once Logger
$_SESSION['allow_logger'] = "yes";
include_once('../scripts/logger.php');

# Here we run a quick aPersona ASM Verification just to ensure no one is trying to steal the session.
// Execute an aPersona verification
# retrive authParam from the update page.
$authParam = $_POST['authParam'];
# Run client IP discovery
 $_SESSION['allow_ip_discovery'] = "yes";
 include_once('../asm_api/ap_ip_discovery.php');
# Pull the current One Time Transaction Cookie.
$cookieName = md5(sha1("salt-8nvgt54wo847tyovw8t4nowenh4tc498t".$_SESSION['ap_sec_pol'].$_SESSION['ldap_email'].$_SESSION['ap_domain_name'].$_SESSION["ldap_risk"]));	//Create a hashed cookie name using md5(sha1(salt+id+domain+adminFlag)) 
$_SESSION['cookieName']=$cookieName;
$_SESSION['cookieVal'] = $_COOKIE[$cookieName];	// Pull the current cookie value if it exists. Clearly the first time a user logs in, this will be null.
$_SESSION['ap_ttype']="LDAP Write ASM Check - Level: ".$_SESSION['ldap_write_asm_level']; 
$_SESSION['ap_otpp']=1;   // We want to pause the OTP.
$_SESSION['ap_otpud3']="Attempting to upate LDAP with new password.";
$_SESSION['ap_sfl']=$_SESSION['ldap_write_asm_level'];    // aPersona Forensic Level to use just before executing an LDAP Write/Change.
$_SESSION['ap_apti'] = substr(str_shuffle("0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"), 0, 40);

# Pull the current One Time Transaction Cookie. (we may not need to do this, but it can't hurt.)
$cookieName = md5(sha1("salt-8nvgt54wo847tyovw8t4nowenh4tc498t".$_SESSION['ap_sec_pol'].$_SESSION['ldap_email'].$_SESSION['ap_domain_name'].$_SESSION["ldap_risk"]));	//Create a hashed cookie name using md5(sha1(salt+id+domain+adminFlag)) 
$_SESSION['cookieName']=$cookieName;
$_SESSION['cookieVal'] = $_COOKIE[$cookieName];	// Pull the current cookie value if it exists. Clearly the first time a user logs in, this will be null.

# Set all the options for the API. & Append the Identity/OTP from post at the end.
$_SESSION['opts']="sfl=".$_SESSION['ap_sfl']."&otpr=".$_SESSION['ap_otpr']."&otpp=".$_SESSION['ap_otpp']."&l=".$_SESSION['ap_sec_pol']."&u=".$_SESSION['ldap_email']."&wr=".$_SESSION['ap_domain_name']."&hName=".$_SESSION['ap_hName']."&otpud1=".$otpud1."&otpud2=".$otpud2."&otpud3=".$_SESSION['ap_otpud3']."&tType=".$_SESSION['ap_ttype']."&apti=".$_SESSION['ap_apti']."&uIp=".$_SESSION['client_ipaddress']."&otpm=".$_SESSION['ap_otpm']."&p=".$_SESSION['ap_p']."&c=".$_SESSION['cookieVal']."&igd=".$_SESSION['ap_igd']."&a=".$_SESSION['authParam']."&o=".$_POST['IdentityCode'];

$_SESSION['allow_ap_api'] = "yes";
include_once('../asm_api/ap_api.php');
$ap_api_service="extAuthenticate.kv?";
aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);

# Here we review the aPersona ASM Return Code. If the OTP has timed out, then the resend will fail and we need to return the user to the Login Page with an error.

switch ($_SESSION['apResp']){
		case 200;  // The OTP was sent successfully. This counts as a successful verification. 
			# Write-update aPersona ASM Cookie/Token
			# Save the OneTimeToken/Cookie set in the aPersona API.
			if ($_SESSION['cVal']!="") setcookie($_SESSION['cookieName'],$_SESSION['cVal'],time()+31536000,null,null,isset($_SERVER["HTTPS"]),TRUE); 	//Set the aPersona Secure (HttpOnly) one-time  use cookie 
		break;
		default:
			#In our case, if the user does not pass with a 200, then we have a problem!!!!
			header('Location: ../Login/index.php?error=We detected a change in operating environments. Contact support.');
			exit();
		}


# in this script we will do the following.
# 1. Pull the post variables from the password reset page. AND, make sure the new passwords match.
# 2. update ldap based on the update field (pwd).
# 3. Re-run the get ldap info to reload the latest values in LDAP.
# 4. Put the user back to the reset-pwd page if not successful. If successful, send the user to the Identity Mgt page, or other page that was passed in the URL.

# Pull Post vars and check them.
if ($_POST['new'] != $_POST['new2']) 
  {
    $_SESSION['allow_reset_pwd'] = "yes";
    header('Location: ../Reset-Password/reset-pwd.php?error=New password entries are not the same. Try again.'); exit();
  }
else
{ # All the new password details are valid from what we can tell. Next we need to try to update the password.
$_SESSION['update_state']="pwd"; 
$_SESSION['new_entry']=$_POST['new'];}


# Connect to LDAP and get user current info.
# Enable the LDAP Connect and Search Scripts for execution & include_once the LDAP Properties file.
$_SESSION['allow_ldap_connection'] = "yes";
include_once('../asm_api/ldap_connection_properties.php');
$_SESSION['allow_ldap_properties'] = "yes";
include_once('../asm_api/ldap_properties.php');

$_SESSION['allow_ldap_search'] = "yes";
include_once('./ldap_search.php');

# check posted 'current' value. Could be alt-email, mobile, voice, or password. Valid methods are: 'ae','s','v','pwd'. 

IF ($_SESSION['update_state']=="pwd") 
	{
	 update_password($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_name'],$_SESSION['new_entry']);
	write_log(200, "Password Reset: ldap_change-reset_pwd - Password was reset.");
	$location = "Location: ".$_SESSION['returnURL']."?msg=Your Password has been updated!";
	header($location); 
	exit(); }
ELSE
	{write_log(300, "Password Reset: ldap_change-reset_pwd - Password reset failed.");
	header('Location: ../Reset-Password/reset.php?error=Something went wrong. Your password was not updated'); exit(); }
	

# Pull the current info from LDAP
# Not sure why this line below is here.... I think we can delete it. Commenting it out.
# get_ldap_info($ldap_login,$ldap_pwd,$_SESSION['ldap_url'],$_SESSION['ldap_email'],$ldap_suadmin_risk,$ldap_high_risk,$ldap_normal_risk,$ldap__alt_email_field,$ldap__mobile_field,$ldap__voice_field);


function update_password($login,$pwd,$url,$ad_name,$newPassword){
//LDAP Bind paramters, need to be an account that can update AD.
$ldap_username = $login;
$ldap_password = $pwd;
$ldap_connection = ldap_connect($url);

// We have to set this option for the version of Active Directory we are using.
ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
if (TRUE === ldap_bind($ldap_connection, $ldap_username, $ldap_password)){

$prefix = $_SESSION["prefix"];
$postfix = $_SESSION["postfix"];
$dn = "dc=".$prefix.",dc=".$postfix;
$ldap_base_dn = 'CN='.$ad_name.',CN=Users,DC='.$prefix.',DC='.$postfix; 

// create the unicode password
$newPassword = "\"" . $newPassword . "\"";
$len = strlen($newPassword);
for ($i = 0; $i < $len; $i++) $newpass .= "{$newPassword{$i}}\000";
$entry["unicodePwd"] = $newpass;

// Modify the password
if (ldap_mod_replace($ldap_connection, $ldap_base_dn, $entry))
{
  # Successfully updated password.
} else
    {
       $_SESSION['password_attempt']++;
       if ($_SESSION['password_attempt'] >= $_SESSION['password_attempt_max_tries']) 
	{ write_log(300, "Password Reset: ldap_change-reset_pwd - User password change failed - too many tries."); header("Location: ../Reset-Password/reset.php?error=You took to many tries on your password update."); exit();  } else 
	{ $_SESSION['allow_reset_pwd'] = "yes"; write_log(202, "Password Reset: ldap_change-reset_pwd - Warning - User typed in an invalid password."); header("Location: ../Reset-Password/reset-pwd.php?error=[Try ".$_SESSION['password_attempt']." of ".$_SESSION['password_attempt_max_tries']."]<br>Your password was not changed. <br>Review the rules.<br>".$_SESSION['password_rules']); 
          exit(); }
     }
}
}

?>