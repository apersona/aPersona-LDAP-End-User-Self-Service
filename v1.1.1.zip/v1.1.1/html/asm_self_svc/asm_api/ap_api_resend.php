<?php
ob_start();
@session_start();
IF ($_SESSION['allow_ap_api_resend'] != "yes"){header('Location: ../Login/index.php?error=aP API Resend Not Allowed.'); exit();}
$_SESSION['allow_ap_api_resend'] = "no";

 $_SESSION['allow_ap_api'] = "yes";
 include_once('../asm_api/ap_api.php');
$ap_api_service="extResendOtp.kv?";

aPextAPI($_SESSION['apersona_asm_url'], $ap_api_service, $_SESSION['opts']);
# echo "<br> WE ARE READY TO SEND THE USER TO THE VERIFY PAGE!!!<br>";
# Here we review the aPersona ASM Return Code. If the OTP has timed out, then the resend will fail and we need to return the user to the Login Page with an error.

switch ($_SESSION['apResp']){
		case 202;  // The OTP was sent successfully. Redirect user back to the Verify Page.
			$_SESSION['allow_verify_page'] = "yes";
			# echo "apMessage".$_SESSION['apMessage']."<br />";
			if ($_SESSION['apMessage'] == "Error in sending OTP" || $_SESSION['apMessage'] == "No Mobile Route for OTP") {header('Location: ../Verify/verify.php?error=There is a problem sending the identity code to your new number.');
			 exit();} else {	header('Location: ../Verify/verify.php?msg=Code resent!'); exit();}


		break;
		case 401;
			header('Location: ../Login/index.php?error=Your identity code has expired. Try logging in again.');
		break;
		default:
			# # echo "There is an unknown error <br />";
			# This default situation is not likely to occur unless your aPersona MFA setup is not working. 
			# In our demo, we send the user back to login with an error. In a live setup, you might want to log the user in and work on fixing the issue.
			header('Location: ../Login/index.php?error=There is a problem (default). Contact support.');

}
exit();

?>