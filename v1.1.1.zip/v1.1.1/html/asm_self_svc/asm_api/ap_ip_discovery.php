<?php session_start();
IF ($_SESSION['allow_ip_discovery'] != "yes"){header('Location: ../Login/index.php?error=Login not permitted.'); exit();}
$_SESSION['allow_ip_discovery'] = "no";

# Just before we execute and aPersona validation, we want to retrieve the client IP address as the server sees it.

if      ( isset($_SERVER["HTTP_X_CLIENT_IP"]) ) 	{$client_ipaddress = $_SERVER["HTTP_X_CLIENT_IP"];} 
else if ( isset($_SERVER["HTTP_X_FORWARDED_FOR"]) ) 	{$client_ipaddress = $_SERVER["HTTP_X_FORWARDED_FOR"];}
else if ( isset($_SERVER["HTTP_X_FORWARDED"]) ) 	{$client_ipaddress = $_SERVER["HTTP_X_FORWARDED"];} 
else if ( isset($_SERVER["HTTP_CLIENT_IP"]) ) 		{$client_ipaddress = $_SERVER["HTTP_CLIENT_IP"];}
else if ( isset($_SERVER["HTTP_FORWARDED_FOR"]) ) 	{$client_ipaddress = $_SERVER["HTTP_FORWARDED_FOR"];}
else if ( isset($_SERVER["HTTP_FORWARDED"]) ) 		{$client_ipaddress = $_SERVER["HTTP_FORWARDED"];}
else if ( isset($_SERVER["REMOTE_ADDR"]) ) 		{$client_ipaddress = $_SERVER["REMOTE_ADDR"];}

?>