<?php
IF ($_SESSION['allow_ldap_connection'] != "yes"){header('Location: ../Login/index.php?error=LDAP connection not permitted.'); exit();}
$_SESSION['allow_ldap_connection'] = "no";

$_SESSION['last_script']="ldap_connection";

// LDAP Connection Properties
// Note: In order for this service to have the rights to update LDAP Information, the credentials below, must have at least 'Domain Admins' rights.

# Pull the core application folder settings, then access the settings from the specified locations.
$ini_array = parse_ini_file("../asm_api/.application_setup.ini");
$ldap_connection_file=$ini_array['ldap_connection_ini_file'];
$ini_array = parse_ini_file($ldap_connection_file);

$ldap_login= $ini_array['ldap_login'];
$ldap_pwd= $ini_array['ldap_pwd'];
$_SESSION['ldap_url']=$ini_array['ldap_url'];
#-echo "ldap_login: ".$ldap_login."<br>";
#-echo "ldap_pwd: ".$ldap_pwd."<br>";
#-echo "ldap_url: ".$_SESSION['ldap_url']."<br>";
?>
