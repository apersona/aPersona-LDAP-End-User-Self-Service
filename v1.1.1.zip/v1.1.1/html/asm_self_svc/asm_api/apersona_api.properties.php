<?php
@session_start();
IF ($_SESSION['allow_apersona_api_properties'] != "yes"){header('Location: ../Login/index.php?error=aP properties not permitted.'); exit();}
$_SESSION['allow_apersona_api_properties'] = "no";

#This file contains the aPersona Demo ASM URL & Security Policy API Keys for the demo.

# Pull the core application folder settings, then access the settings from the specified locations.
$ini_array = parse_ini_file("../asm_api/.application_setup.ini");
$api_properties_file=$ini_array['apersona_api_properties_ini_file'];
$ini_array = parse_ini_file($api_properties_file);

#aPersona ASM url   (Make sure there is no trailing '/' at the end)

$_SESSION['apersona_asm_url']=$ini_array['apersona_asm_url'];

#aPersona ASM Security Policy API Key for Default Risk Users: 
$default_ap_api_license_key=$ini_array['default_ap_api_license_key'];

#aPersona ASM Security Policy API Key for Normal Risk Users: 
$normal_ap_api_license_key=$ini_array['normal_ap_api_license_key'];

#aPersona ASM Security Policy API Key for High Risk Users: 
$high_ap_api_license_key=$ini_array['high_ap_api_license_key'];

#aPersona ASM Security Policy API Key for Hishest Risk Users: 
$suadmin_ap_api_license_key=$ini_array['suadmin_ap_api_license_key'];

?>