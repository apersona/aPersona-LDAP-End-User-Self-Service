<?php
IF ($_SESSION['allow_ap_api'] != "yes"){header('Location: ../Login/index.php?error=aP API Not Allowed.'); exit();}
$_SESSION['allow_ap_api'] = "no";

function aPextAPI($url, $api, $api_opts) {
#	Make the aPersona Web Service call via CURL
# # echo "Debug ap_api 1 <br>";
	$api_url="$url"."/".$api;
#	# echo "URL for API= ".$api_url."<br>";
	$ch = curl_init();                    // initiate curl
# # echo "Debug ap_api 2<br>";
#	# echo "ch= ".$ch."<br>";
	curl_setopt($ch, CURLOPT_URL,$api_url);
	curl_setopt($ch, CURLOPT_POST, true);  // tell curl you want to post something
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1); // tell curl not to send output to screen
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);  // Optional Param to tell Curl to not verify SSL Cert on aPersona ASM Svr. 
	curl_setopt($ch, CURLOPT_POSTFIELDS, $api_opts);	// Setup the json options 
	$kvResponseJson = curl_exec ($ch); // execute
# # echo "Debug ap_api 3 <br>";
#    Error Checking - Note: If curl fails, it may be because selinux is set to enforcing.
#    # echo curl_getinfo($ch) . '<br/>';
## echo "Debug ap_api 4 <br>";
#    # echo curl_errno($ch) . '<br/>';
## echo "Debug ap_api 5 <br>";
#    # echo curl_error($ch) . '<br/>';
## echo "Debug ap_api 6 <br>";
#    exit();
	curl_close ($ch); // close curl handle

#	var_dump($kvResponseJson); // show output
	$_SESSION['kvResponseJson'] = $kvResponseJson;		//XXXXXXXXXXXXXXXXXXXX Comment out. For testing only

	$cVal = json_decode($kvResponseJson)->{'identifier'};  // Pull the One time trans cookie Key from the aPersona response.
	$_SESSION['cVal'] = $cVal;				//XXXXXXXXXXXXXXXXXXXX Comment out. For testing only

	$apResp = json_decode($kvResponseJson)->{'code'};	// Pull the code from the aPersona ASM response.
	$_SESSION['apResp'] = $apResp;
	$apMessage = json_decode($kvResponseJson)->{'message'};	// Pull the code from the aPersona ASM response.
	$_SESSION['apMessage'] = $apMessage;
## echo "Debug ap_api 7 <br>";
}

?>
