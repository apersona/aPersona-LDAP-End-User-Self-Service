<?php
IF ($_SESSION['allow_ldap_properties'] != "yes"){header('Location: ../Login/index.php?error=LDAP properties not permitted.'); exit();}
$_SESSION['allow_ldap_properties'] = "no";

$_SESSION['last_script']="ldap_properties";

# $ini_array = parse_ini_file("ldap_properties.ini");

# Pull the core application folder settings, then access the settings from the specified locations.
$ini_array = parse_ini_file("../asm_api/.application_setup.ini");
$ldap_properties_file=$ini_array['ldap_properties_ini_file'];
$ini_array = parse_ini_file($ldap_properties_file);

// LDAP Security Group Risk Levels. Note: All users begin in the "default" security group, then will be bumped up to next level if they are a part of any group listed.
// List all or any part of the Security Group names, separated by commas. Searching for the word 'user', should (for MSFT AD) in effect, put all users in the corresponding risk level. 
$ldap_suadmin_risk=$ini_array['ldap_suadmin_risk'];			// Security groups with suadmin levels of risk. Any group with the word 'admin' as an example.
$ldap_high_risk=$ini_array['ldap_high_risk'];		// Security groups with high levels of risk. Any group with the word 'exec', or 'hr' as an example.
$ldap_normal_risk=$ini_array['ldap_normal_risk'];		// Security groups with normal levels of risk. Any group with the word 'supplier', or 'contractor' as an example.
# 'default' security will be used if user is not in an above search.

//LDAP field mappings for Alt-Email, Mobile Number & Voice Number. Note: If no voice number is found, Mobile will automatically be used for Voice.
$ldap__alt_email_field=$ini_array['ldap__alt_email_field'];				// For AD the most likely values are: 'mail" or "othermailbox". (The following note is not yet supported=>  If you enter "disabled", then the service will not use this method.)
$ldap__mobile_field=$ini_array['ldap__mobile_field'];				// For AD the most likely value is "mobile". (The following note is not yet supported=>  If you enter "disabled", then the service will not use this method.)
$ldap__voice_field=$ini_array['ldap__voice_field'];				// For AD the most likely value is "telephonenumber". (The following note is not yet supported=>  If you enter "disabled", then the service will not use this method.)

#echo "ldap__alt_email_field: ".$ldap__alt_email_field."<br>";
#echo "ldap__mobile_field: ".$ldap__mobile_field."<br>";
#echo "ldap__voice_field: ".$ldap__voice_field."<br>";
#exit();

# Consult your LDAP/AD Password Rules for this variable.
$_SESSION['password_rules']=$ini_array['password_rules'];

$_SESSION['password_attempt_max_tries']=$ini_array['password_attempt_max_tries'];

# SELF SERVICE LOGIN INFO/DETAILS
$disallow_login_groups=$ini_array['disallow_login_groups'];		// Valid entries separated by commas:  'suadmin, high, normal, default'. To allow all groups to login, set it to null: $disallow_login_groups='';


$_SESSION['ldap_write_asm_level']=$ini_array['ldap_write_asm_level'];


# aPersona Verification Settings. 
# Some explaination will be helpful here.
# There are a number of potential issues that the following settings help us address. Those issues are:
# 1) A hacker can easily attempt multiple failed logins in succession and cause the user's account to be locked. To fight this, the user must pass a minimal verification first, before the password is verified.
# 2) If the user is prompted to verify their identity with a one-time-passcode before their password is checked, then a hacker could generate unnessary OTP's to the user, which is not specifically a problem, 
#    but we want to minimize these. To fight this, the initial minimal verification allows the program to go ahead and check the users password up front (provided it passes), 
#    giving us additional assurance that the legitimate user is logging in, before we send the required aPersona verifications to the user.
# Conslusion: Therefore, we suggest that the minimal initial verification level be set to a level 2, 3, or 4 as an initial check. Of course all levels 1-6 are available here.

# Set the minimum aPersona Security Policy Level that must be passed in order for the Self Service Progam to check the user's password before additional required aPersona Verifications are performed.
# IMPORTANT NOTE HERE: All aPersona verifications in this application override the Security Policy Levels that are defined in ASM. However, ASM will not allow a security policy override to "lower" the forensic level.
# Therefore, for this application, the security policy for each risk group should be set to the minimum level that is defined below. This also means that it's a good idea not to share the ASM Security Policies used
# for this service with any other service or services.
$suadmin_risk_min_level=$ini_array['suadmin_risk_min_level'];
$high_risk_min_level=$ini_array['high_risk_min_level'];
$normal_risk_min_level=$ini_array['normal_risk_min_level'];
$default_risk_min_level=$ini_array['default_risk_min_level'];

# Set the minimum number of aPersona validations required to login to ASM ID Mgmt.
$_SESSION['require_org_email_verification']=$ini_array['require_org_email_verification']; 		# Default is "no".   If "yes", then the first organizational verification cannot be skipped.
$_SESSION['allow_skipping_org_email_pwd_reset']=$ini_array['allow_skipping_org_email_pwd_reset']; 	# Default is "yes".
$_SESSION['suadmin_min_verifications']=$ini_array['suadmin_min_verifications']; 
$_SESSION['high_min_verifications']=$ini_array['high_min_verifications']; 
$_SESSION['normal_min_verifications']=$ini_array['normal_min_verifications'];
$_SESSION['default_min_verifications']=$ini_array['default_min_verifications'];

# Set the maximum number of aPersona validations required to login to ASM ID Mgmt. 
# ASM Verification Management will automatically increase the verification number up to these levels as more channels are set/added for the user.
# For example: If suadmin_min is set to 2, and max is set to 3, then suadmin must have at least two verifications to login. 
# But if they have three channels available, then three verifications must be passed to login. Any value for max that is less than min, will be ignored.
# Essentially, this feature increases the strength of the login as the user adds more otp methods. It will also decrease the strength if the user removes an OTP Method.
# To deactivate this feature simply set the max to the same number as min above.
$_SESSION['suadmin_max_verifications']=$ini_array['suadmin_max_verifications'];
$_SESSION['high_max_verifications']=$ini_array['high_max_verifications'];
$_SESSION['normal_max_verifications']=$ini_array['normal_max_verifications'];
$_SESSION['default_max_verifications']=$ini_array['default_max_verifications'];


# SELF SERVICE PASSWORD RESET INFO/DETAILS
$_SESSION['allow_pwd_reset']=$ini_array['allow_pwd_reset'];
$disallow_pwd_reset_groups=$ini_array['disallow_pwd_reset_groups'];		// Valid entries separated by commas:  'suadmin, high, normal, default'. To allow all groups to login, set it to null: $disallow_login_groups='';

$_SESSION['skip_org_email_reset_verification']=$ini_array['skip_org_email_reset_verification'];  # Default is "yes". In a password reset situation, the user most likely does not know their Pwd, and won't be able to get an otp to their org email. If you enter "no", User must pass Org Email verification.
$_SESSION['suadmin_min_reset_verifications']=$ini_array['suadmin_min_reset_verifications'];
$_SESSION['high_min_reset_verifications']=$ini_array['high_min_reset_verifications'];
$_SESSION['normal_min_reset_verifications']=$ini_array['normal_min_reset_verifications'];
$_SESSION['default_min_reset_verifications']=$ini_array['default_min_reset_verifications'];

$_SESSION['suadmin_max_reset_verifications']=$ini_array['suadmin_max_reset_verifications'];
$_SESSION['high_max_reset_verifications']=$ini_array['high_max_reset_verifications'];
$_SESSION['normal_max_reset_verifications']=$ini_array['normal_max_reset_verifications'];
$_SESSION['default_max_reset_verifications']=$ini_array['default_max_reset_verifications'];

# HELP DESK INVOLVEMENT REQUIRED? (VERIFIED LAST IF REQUIRED) [Not yet implemented.
#Help_Desk_Email=otp_help@domain.com
#Help_Desk_Phone_Number=+1-845-334-4587
#suadmin_Risk_Login_Require_HDesk_OTP=yes/no
#suadmin_Risk_Update_Require_HDesk_OTP=yes/no
#suadmin_Risk_Pwd_Reset_Require_HDesk_OTP=yes/no
#High_Risk_Login_Require_HDesk_OTP=yes/no
#High_Risk_Update_Require_HDesk_OTP=yes/no
#High_Risk_Pwd_Reset_Require_HDesk_OTP=yes/no
#normal_Risk_Login_Require_HDesk_OTP=yes/no
#normal_Risk_Update_Require_HDesk_OTP=yes/no
#normal_Risk_Pwd_Reset_Require_HDesk_OTP=yes/no
#default_Risk_Login_Require_HDesk_OTP=yes/no
#default_Risk_Update_Require_HDesk_OTP=yes/no
#default_Risk_Pwd_Reset_Require_HDesk_OTP=yes/no

