<?php
# 
session_start(); # Starts the session
if ($_SESSION['id_mgmt_session_salt']==""){header('Location: ../Login/index.php?msg=This session has timed out.'); exit();}
IF ($_SESSION['allow_update_page'] != $_SESSION['id_mgmt_session_salt']){header('Location: ../Login/index.php?error=aP LDAP Update Page Not Allowed.'); exit();}
$_SESSION['allow_ldap_update'] = $_SESSION['id_mgmt_session_salt'];
# Run client IP discovery
 $_SESSION['allow_ip_discovery'] = "yes";
 include_once('../asm_api/ap_ip_discovery.php');
 if ( $_SESSION['initial_ip']!=$client_ipaddress) {
	header('Location: ../Login/index.php?error=Change in operating environment.'); 
	exit();
	}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Update</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- meta name="viewport" content="width=device-width, user-scalable=no" -->
<meta name="viewport" content="width=device-width, initial-scale=.9">
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: white;
   color: grey;
   text-align: center;
   font-size: 12px;
}
</style>
<style>
p.ex2 {
  margin-left: 8px;
}
</style>
<script>
  setTimeout(function(){
    document.getElementById('info-message').style.display = 'none';
    /* or
    var item = document.getElementById('info-message')
    item.parentNode.removeChild(item); 
    */
  }, 5000);
</script>

<script type="text/javascript" src="../Login/jquery.js"></script>
<script type="text/javascript" src="../Login/jquery-ui.js"></script>
<script type="text/javascript" src="../Login/polyfiller.js"></script>

<link rel="stylesheet" type="text/css" href="../fusion.css">
<link rel="stylesheet" type="text/css" href="../style.css">
<link rel="stylesheet" type="text/css" href="../site.css">
</head>
<body style="background-color: rgb(255,255,255); background-image: none; margin: 0px;" class="nof-centerBody">
  <div align="center">
    <table border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td width="3022">
                <table id="Table7" border="0" cellspacing="0" cellpadding="0" width="100%" style="background-color: rgb(245,243,241); height: 54px;">
                  <tr style="height: 54px;">
                    <td width="43" id="Cell288"></td>
                    <td width="2801" id="Cell289">
                      <p class="ex2" style="margin-bottom: 0px;"><a href="../ID-Mgmt/id-mgmt.php"><img id="Picture26" height="40" width="201" src="../branding/logo.png" vspace="0" hspace="0" align="top" border="0" alt="logo" title="logo"></p>
                    </td>
                    <td width="96" id="Cell309">
                      <p style="text-align: left; margin-bottom: 0px;"><b><span style="color: rgb(31,78,121); font-weight: bold;"></span></b><a href="../Login/index.php?msg=You have logged out."><img id="Picture32" height="22" width="74" src="../branding/signout_button.png" vspace="0" hspace="0" align="top" border="0" alt="signoutbutton" title="signoutbutton"></a></p>
                    </td>
                    <td width="18" id="Cell310"></td>
                    <td width="64" style="background-color: rgb(31,78,121);" id="Cell311">
                      <p style="text-align: center; margin-bottom: 0px;"><b><span style="font-size: 24px; color: rgb(251,251,251); font-weight: bold;">&nbsp;<?php echo $_SESSION['initials'];?>&nbsp; </span></b></p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td height="9"></td>
            </tr>
            <tr valign="top" align="left">
              <td width="3023">
                <table id="Table6" border="0" cellspacing="2" cellpadding="2" width="100%" style="height: 106px;">
                  <tr style="height: 110px;">
                    <td width="41" id="Cell150">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                    <td width="98%" id="Cell152">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td align="center">
                            <table id="Table11" border="0" cellspacing="0" cellpadding="0" width="11" style="height: 85px;">
                              <tr style="height: 34px;">
                                <td width="9" id="Cell163">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td width="342" id="Cell290">
                                  <p style="margin-bottom: 0px;"><b><span style="font-size: 28px; font-weight: bold;"><?php echo $_SESSION['company_name'];?></span></b></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell164">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td align="left" id="Cell291">
                                  <p style="margin-bottom: 0px;"><b><span style="font-weight: bold;">&nbsp;<?php echo $_SESSION['app_title'];?></span></b></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell165">
                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td align="center"><img id="Picture25" height="6" width="9" src="../branding/450sp.png" border="0" alt="450sp" title="450sp"></td>
                                    </tr>
                                  </table>
                                </td>
                                <td id="Cell292">
                                  <p style="margin-bottom: 0px;"><img id="Picture18" height="7" width="342" src="../branding/450sp.png" vspace="0" hspace="0" align="middle" border="0" alt="450sp" title="450sp">&nbsp;</p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell166">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td align="left" id="Cell301">
                                  <p style="margin-bottom: 0px;"><i>&nbsp;<?php echo $_SESSION['update_instructions'];?></i></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell296">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td id="Cell297">
                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td align="left"><img id="Picture31" height="8" width="342" src="../branding/450spWtLGr.png" border="0" alt="450spWtLGr" title="450spWtLGr"></td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td width="25" id="Cell153">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td width="3023">
                <table id="Table9" border="0" cellspacing="0" cellpadding="0" width="100%" style="height: 253px;">
                  <tr style="height: auto;">
                    <td width="41" id="Cell302">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                    <td width="98%" id="Cell303">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td align="center">

                           <form name="asmIDMgmtUpdate" method="post" target='_self' action='../scripts/ldap_update.php'>

				<!-- aPersona hidden variable authParam passed as a post variable. -->
				<input type="hidden" id="authParam" name="authParam"/>
				<!-- End aPersona integration section -->
				<input type="hidden" id="allow_update" name="allow_update" value="yes">

                              <table border="0" cellspacing="0" cellpadding="0">
                                <tr valign="top" align="left">
                                  <td width="351">
                                    <table id="Table10" border="0" cellspacing="0" cellpadding="0" width="98%" style="height: 268px;">
                                      <tr style="height: 6px;">
                                        <td width="9" id="Cell313"></td>
                                        <td colspan="7" id="Cell312"></td>
                                      </tr>


<!-- Current Information Section -->

                                      <tr style="height: 27px;">
                                        <td id="Cell167"></td>
                                        <td colspan="7" valign="middle" id="CurrentInfoTitleCell">
                                          <p style="text-align: left; margin-bottom: 0px;">&nbsp;<b><span style="font-weight: bold;"><?php echo $_SESSION['update_new_method_1']; ?></span></b></p>
                                        </td>
                                      </tr>
                                      <tr style="height: 24px;">
                                        <td id="Cell168"></td>
                                        <td valign="middle" width="58" id="CurrentInfoCell">
                                          <p style="margin-bottom: 0px;">
                                            <select id="CurrentCountryCode" name="CurrentCountryCode" style="font-size: 20px; height: 24px;">
                                              <option value="+1" selected="selected">+1</option>
<option value="+7">+7</option>
<option value="+20">+20</option>
<option value="+27">+27</option>
<option value="+30">+30</option>
<option value="+31">+31</option>
<option value="+32">+32</option>
<option value="+33">+33</option>
<option value="+34">+34</option>
<option value="+36">+36</option>
<option value="+39">+39</option>
<option value="+40">+40</option>
<option value="+41">+41</option>
<option value="+43">+43</option>
<option value="+44">+44</option>
<option value="+45">+45</option>
<option value="+46">+46</option>
<option value="+47">+47</option>
<option value="+47">+47</option>
<option value="+48">+48</option>
<option value="+49">+49</option>
<option value="+51">+51</option>
<option value="+52">+52</option>
<option value="+53">+53</option>
<option value="+54">+54</option>
<option value="+55">+55</option>
<option value="+56">+56</option>
<option value="+57">+57</option>
<option value="+58">+58</option>
<option value="+60">+60</option>
<option value="+61">+61</option>
<option value="+61">+61</option>
<option value="+61">+61</option>
<option value="+62">+62</option>
<option value="+63">+63</option>
<option value="+64">+64</option>
<option value="+64">+64</option>
<option value="+65">+65</option>
<option value="+66">+66</option>
<option value="+81">+81</option>
<option value="+82">+82</option>
<option value="+84">+84</option>
<option value="+86">+86</option>
<option value="+90">+90</option>
<option value="+91">+91</option>
<option value="+92">+92</option>
<option value="+93">+93</option>
<option value="+94">+94</option>
<option value="+95">+95</option>
<option value="+98">+98</option>
<option value="+211">+211</option>
<option value="+212">+212</option>
<option value="+212">+212</option>
<option value="+213">+213</option>
<option value="+216">+216</option>
<option value="+218">+218</option>
<option value="+220">+220</option>
<option value="+221">+221</option>
<option value="+222">+222</option>
<option value="+223">+223</option>
<option value="+224">+224</option>
<option value="+225">+225</option>
<option value="+226">+226</option>
<option value="+227">+227</option>
<option value="+228">+228</option>
<option value="+229">+229</option>
<option value="+230">+230</option>
<option value="+231">+231</option>
<option value="+232">+232</option>
<option value="+233">+233</option>
<option value="+234">+234</option>
<option value="+235">+235</option>
<option value="+236">+236</option>
<option value="+237">+237</option>
<option value="+238">+238</option>
<option value="+239">+239</option>
<option value="+240">+240</option>
<option value="+241">+241</option>
<option value="+242">+242</option>
<option value="+243">+243</option>
<option value="+244">+244</option>
<option value="+245">+245</option>
<option value="+246">+246</option>
<option value="+248">+248</option>
<option value="+249">+249</option>
<option value="+250">+250</option>
<option value="+251">+251</option>
<option value="+252">+252</option>
<option value="+253">+253</option>
<option value="+254">+254</option>
<option value="+255">+255</option>
<option value="+256">+256</option>
<option value="+257">+257</option>
<option value="+258">+258</option>
<option value="+260">+260</option>
<option value="+261">+261</option>
<option value="+262">+262</option>
<option value="+262">+262</option>
<option value="+263">+263</option>
<option value="+264">+264</option>
<option value="+265">+265</option>
<option value="+266">+266</option>
<option value="+267">+267</option>
<option value="+268">+268</option>
<option value="+269">+269</option>
<option value="+290">+290</option>
<option value="+291">+291</option>
<option value="+297">+297</option>
<option value="+298">+298</option>
<option value="+299">+299</option>
<option value="+350">+350</option>
<option value="+351">+351</option>
<option value="+352">+352</option>
<option value="+353">+353</option>
<option value="+354">+354</option>
<option value="+355">+355</option>
<option value="+356">+356</option>
<option value="+357">+357</option>
<option value="+358">+358</option>
<option value="+359">+359</option>
<option value="+370">+370</option>
<option value="+371">+371</option>
<option value="+372">+372</option>
<option value="+373">+373</option>
<option value="+374">+374</option>
<option value="+375">+375</option>
<option value="+376">+376</option>
<option value="+377">+377</option>
<option value="+378">+378</option>
<option value="+379">+379</option>
<option value="+380">+380</option>
<option value="+381">+381</option>
<option value="+382">+382</option>
<option value="+383">+383</option>
<option value="+385">+385</option>
<option value="+386">+386</option>
<option value="+387">+387</option>
<option value="+389">+389</option>
<option value="+420">+420</option>
<option value="+421">+421</option>
<option value="+423">+423</option>
<option value="+500">+500</option>
<option value="+501">+501</option>
<option value="+502">+502</option>
<option value="+503">+503</option>
<option value="+504">+504</option>
<option value="+505">+505</option>
<option value="+506">+506</option>
<option value="+507">+507</option>
<option value="+508">+508</option>
<option value="+509">+509</option>
<option value="+590">+590</option>
<option value="+590">+590</option>
<option value="+591">+591</option>
<option value="+592">+592</option>
<option value="+593">+593</option>
<option value="+595">+595</option>
<option value="+597">+597</option>
<option value="+598">+598</option>
<option value="+599">+599</option>
<option value="+599">+599</option>
<option value="+670">+670</option>
<option value="+672">+672</option>
<option value="+673">+673</option>
<option value="+674">+674</option>
<option value="+675">+675</option>
<option value="+676">+676</option>
<option value="+677">+677</option>
<option value="+678">+678</option>
<option value="+679">+679</option>
<option value="+680">+680</option>
<option value="+681">+681</option>
<option value="+682">+682</option>
<option value="+683">+683</option>
<option value="+685">+685</option>
<option value="+686">+686</option>
<option value="+687">+687</option>
<option value="+688">+688</option>
<option value="+689">+689</option>
<option value="+690">+690</option>
<option value="+691">+691</option>
<option value="+692">+692</option>
<option value="+850">+850</option>
<option value="+852">+852</option>
<option value="+853">+853</option>
<option value="+855">+855</option>
<option value="+856">+856</option>
<option value="+880">+880</option>
<option value="+886">+886</option>
<option value="+960">+960</option>
<option value="+961">+961</option>
<option value="+962">+962</option>
<option value="+963">+963</option>
<option value="+964">+964</option>
<option value="+965">+965</option>
<option value="+966">+966</option>
<option value="+967">+967</option>
<option value="+968">+968</option>
<option value="+970">+970</option>
<option value="+971">+971</option>
<option value="+972">+972</option>
<option value="+973">+973</option>
<option value="+974">+974</option>
<option value="+975">+975</option>
<option value="+976">+976</option>
<option value="+977">+977</option>
<option value="+992">+992</option>
<option value="+993">+993</option>
<option value="+994">+994</option>
<option value="+995">+995</option>
<option value="+996">+996</option>
<option value="+998">+998</option>

                                            </select>
                                          </p>
                                        </td>
                                        <td width="2" id="Cell314"></td>
                                        <td colspan="5" valign="middle" id="Cell315">
                                          <table width="100%" border="0" cellspacing="7" cellpadding="0">
                                            <tr>
                                              <td align="left"><input type="<?php echo $_SESSION['input_type']; ?>" id="Current" name="current" required class="field required" required="true" size="31" maxlength="250" style="font-size: 20px; white-space: pre; width: 244px;" placeholder="<?php echo $_SESSION['current_placeholder']; ?>" </td>
                                            </tr>
                                          </table>
                                        </td>
                                      </tr>
                                      <tr style="height: 24px;">
                                        <td id="Cell169"></td>
                                        <td colspan="7" valign="middle" id="Cell304">
                                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                            <tr>
                                              <td align="center"><img id="Picture33" height="5" width="190" src="../branding/450spWtGr.png" border="0" alt="450spWtGr" title="450spWtGr"></td>
                                            </tr>
                                          </table>
                                        </td>
                                      </tr>


<!-- New Information Section -->
                                      <tr style="height: 20px;">
                                        <td id="Cell170"></td>
                                        <td colspan="7" valign="middle" style="background-color: rgb(255,255,255);" id="NewInfoTitleCell">
                                          <p style="text-align: left; margin-bottom: 0px;">&nbsp; <b><span style="font-weight: bold;"><?php echo $_SESSION['update_new_method_2']; ?></span></b></p>
                                        </td>
                                      </tr>
                                      <tr style="height: 25px;">
                                        <td id="Cell171"></td>
                                        <td colspan="3" valign="middle" style="background-color: rgb(255,255,255);" id="NewInfoCell">
                                          <p style="margin-bottom: 0px;">
                                            <select id="NewCountryCode" name="NewCountryCode" style="font-size: 20px; height: 24px;">
                                              <option value="+1" selected="selected">+1</option>
<option value="+7">+7</option>
<option value="+20">+20</option>
<option value="+27">+27</option>
<option value="+30">+30</option>
<option value="+31">+31</option>
<option value="+32">+32</option>
<option value="+33">+33</option>
<option value="+34">+34</option>
<option value="+36">+36</option>
<option value="+39">+39</option>
<option value="+40">+40</option>
<option value="+41">+41</option>
<option value="+43">+43</option>
<option value="+44">+44</option>
<option value="+45">+45</option>
<option value="+46">+46</option>
<option value="+47">+47</option>
<option value="+47">+47</option>
<option value="+48">+48</option>
<option value="+49">+49</option>
<option value="+51">+51</option>
<option value="+52">+52</option>
<option value="+53">+53</option>
<option value="+54">+54</option>
<option value="+55">+55</option>
<option value="+56">+56</option>
<option value="+57">+57</option>
<option value="+58">+58</option>
<option value="+60">+60</option>
<option value="+61">+61</option>
<option value="+61">+61</option>
<option value="+61">+61</option>
<option value="+62">+62</option>
<option value="+63">+63</option>
<option value="+64">+64</option>
<option value="+64">+64</option>
<option value="+65">+65</option>
<option value="+66">+66</option>
<option value="+81">+81</option>
<option value="+82">+82</option>
<option value="+84">+84</option>
<option value="+86">+86</option>
<option value="+90">+90</option>
<option value="+91">+91</option>
<option value="+92">+92</option>
<option value="+93">+93</option>
<option value="+94">+94</option>
<option value="+95">+95</option>
<option value="+98">+98</option>
<option value="+211">+211</option>
<option value="+212">+212</option>
<option value="+212">+212</option>
<option value="+213">+213</option>
<option value="+216">+216</option>
<option value="+218">+218</option>
<option value="+220">+220</option>
<option value="+221">+221</option>
<option value="+222">+222</option>
<option value="+223">+223</option>
<option value="+224">+224</option>
<option value="+225">+225</option>
<option value="+226">+226</option>
<option value="+227">+227</option>
<option value="+228">+228</option>
<option value="+229">+229</option>
<option value="+230">+230</option>
<option value="+231">+231</option>
<option value="+232">+232</option>
<option value="+233">+233</option>
<option value="+234">+234</option>
<option value="+235">+235</option>
<option value="+236">+236</option>
<option value="+237">+237</option>
<option value="+238">+238</option>
<option value="+239">+239</option>
<option value="+240">+240</option>
<option value="+241">+241</option>
<option value="+242">+242</option>
<option value="+243">+243</option>
<option value="+244">+244</option>
<option value="+245">+245</option>
<option value="+246">+246</option>
<option value="+248">+248</option>
<option value="+249">+249</option>
<option value="+250">+250</option>
<option value="+251">+251</option>
<option value="+252">+252</option>
<option value="+253">+253</option>
<option value="+254">+254</option>
<option value="+255">+255</option>
<option value="+256">+256</option>
<option value="+257">+257</option>
<option value="+258">+258</option>
<option value="+260">+260</option>
<option value="+261">+261</option>
<option value="+262">+262</option>
<option value="+262">+262</option>
<option value="+263">+263</option>
<option value="+264">+264</option>
<option value="+265">+265</option>
<option value="+266">+266</option>
<option value="+267">+267</option>
<option value="+268">+268</option>
<option value="+269">+269</option>
<option value="+290">+290</option>
<option value="+291">+291</option>
<option value="+297">+297</option>
<option value="+298">+298</option>
<option value="+299">+299</option>
<option value="+350">+350</option>
<option value="+351">+351</option>
<option value="+352">+352</option>
<option value="+353">+353</option>
<option value="+354">+354</option>
<option value="+355">+355</option>
<option value="+356">+356</option>
<option value="+357">+357</option>
<option value="+358">+358</option>
<option value="+359">+359</option>
<option value="+370">+370</option>
<option value="+371">+371</option>
<option value="+372">+372</option>
<option value="+373">+373</option>
<option value="+374">+374</option>
<option value="+375">+375</option>
<option value="+376">+376</option>
<option value="+377">+377</option>
<option value="+378">+378</option>
<option value="+379">+379</option>
<option value="+380">+380</option>
<option value="+381">+381</option>
<option value="+382">+382</option>
<option value="+383">+383</option>
<option value="+385">+385</option>
<option value="+386">+386</option>
<option value="+387">+387</option>
<option value="+389">+389</option>
<option value="+420">+420</option>
<option value="+421">+421</option>
<option value="+423">+423</option>
<option value="+500">+500</option>
<option value="+501">+501</option>
<option value="+502">+502</option>
<option value="+503">+503</option>
<option value="+504">+504</option>
<option value="+505">+505</option>
<option value="+506">+506</option>
<option value="+507">+507</option>
<option value="+508">+508</option>
<option value="+509">+509</option>
<option value="+590">+590</option>
<option value="+590">+590</option>
<option value="+591">+591</option>
<option value="+592">+592</option>
<option value="+593">+593</option>
<option value="+595">+595</option>
<option value="+597">+597</option>
<option value="+598">+598</option>
<option value="+599">+599</option>
<option value="+599">+599</option>
<option value="+670">+670</option>
<option value="+672">+672</option>
<option value="+673">+673</option>
<option value="+674">+674</option>
<option value="+675">+675</option>
<option value="+676">+676</option>
<option value="+677">+677</option>
<option value="+678">+678</option>
<option value="+679">+679</option>
<option value="+680">+680</option>
<option value="+681">+681</option>
<option value="+682">+682</option>
<option value="+683">+683</option>
<option value="+685">+685</option>
<option value="+686">+686</option>
<option value="+687">+687</option>
<option value="+688">+688</option>
<option value="+689">+689</option>
<option value="+690">+690</option>
<option value="+691">+691</option>
<option value="+692">+692</option>
<option value="+850">+850</option>
<option value="+852">+852</option>
<option value="+853">+853</option>
<option value="+855">+855</option>
<option value="+856">+856</option>
<option value="+880">+880</option>
<option value="+886">+886</option>
<option value="+960">+960</option>
<option value="+961">+961</option>
<option value="+962">+962</option>
<option value="+963">+963</option>
<option value="+964">+964</option>
<option value="+965">+965</option>
<option value="+966">+966</option>
<option value="+967">+967</option>
<option value="+968">+968</option>
<option value="+970">+970</option>
<option value="+971">+971</option>
<option value="+972">+972</option>
<option value="+973">+973</option>
<option value="+974">+974</option>
<option value="+975">+975</option>
<option value="+976">+976</option>
<option value="+977">+977</option>
<option value="+992">+992</option>
<option value="+993">+993</option>
<option value="+994">+994</option>
<option value="+995">+995</option>
<option value="+996">+996</option>
<option value="+998">+998</option>
                                            </select>
                                          </p>
                                        </td>
                                        <td width="5" id="Cell317"></td>
                                        <td colspan="3" valign="middle" id="Cell316">
                                          <p style="margin-bottom: 0px;"><input type="<?php echo $_SESSION['input_type']; ?>" id="New" name="new" required class="field required" required="true" size="31" maxlength="250" style="font-size: 20px; white-space: pre; width: 244px;" placeholder="<?php echo $_SESSION['new_placeholder']; ?>"></p>
                                        </td>
                                      </tr>
<!-- New Information 2 Section -->



<!-- Update Button Section -->
                                      <tr style="height: 20px;">
                                        <td id="Cell175"></td>
                                        <td colspan="7" id="Cell306"></td>
                                      </tr>


                                      <tr style="height: 28px;">
                                        <td id="Cell177"></td>
                                        <td colspan="7" valign="middle" id="UpdatePasswordTitleCell">
                                          <p style="text-align: left; margin-bottom: 0px;"><b><span style="font-weight: bold;"></span>
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                              <tr>
                                                <td align="center"><input type="image" id="FormsButton17" name="UpdateButton" value="Update" src="../branding/update_button.png" style="height: 40px; width: 95px;">&nbsp;&nbsp;<a href="../ID-Mgmt/id-mgmt.php"><img border="0" alt="back_button" src="../branding/back_button.png" width="95" height="40"></td>
                                              </tr>
                                            </table>
                                            </b></td>
                                        </tr>
                                        <tr style="height: 7px;">
                                          <td id="Cell178"></td>
                                          <td colspan="7" id="Cell307"></td>
                                        </tr>
                                        <tr style="height: 19px;">
                                          <td id="Cell179"></td>
                                          <td colspan="7" valign="middle" id="Cell287">
                                            <p style="margin-bottom: 0px;"><b><p style="margin-bottom: 0px;"><p id="info-message"><span style="font-size: 14px; color: rgb(159,41,41);"><?php if(strpos($_GET['error'],"<?php")  ||  strpos($_GET['msg'],"<?php")) {header('Location: ../Login/index.php?error=Application violation.'); exit();} ?><?php $error = $_GET['error']; echo($error);?><span style="font-size: 14px; color: rgb(46,139,87);"><?php $msg = $_GET['msg']; echo($msg);?></span></p><b>
                                          </td>
                                        </tr>
                                        <tr style="height: 35px;">
                                          <td id="Cell180">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                              <tr>
                                                <td align="center"><img id="Picture24" height="6" width="9" src="../branding/450sp.png" border="0" alt="450sp" title="450sp"></td>
                                              </tr>
                                            </table>
                                          </td>
                                          <td colspan="7" valign="middle" id="Cell162">
                                            <p style="margin-bottom: 0px;"><img id="Picture17" height="7" width="342" src="../branding/450sp.png" vspace="0" hspace="0" align="middle" border="0" alt="450sp" title="450sp"></p>
                                          </td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                                </table>
                              </form>
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td width="25" id="Cell308">
                        <p style="margin-bottom: 0px;">&nbsp;</p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <div class="footer">
  <p><?php echo $_SESSION['footer']; ?></p>
</div>

          </td>
        </tr>
      </table>
    </div>
  </body>
  </html>
   