<?php
header('Location: ../Reset-Password/reset.php'); exit();
?>