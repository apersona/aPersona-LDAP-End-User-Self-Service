<?php
# When the login pages loads, we want to ensure all sessions are cleared.
session_start(); # Starts the session
ob_start();
@session_start();
IF ($_SESSION['allow_reset_pwd'] != "yes"){header('Location: ../Reset-Password/reset.php?error=reset-pwd: Reset not permitted.'); exit();}
$_SESSION['allow_reset_pwd'] = "no";
$_SESSION['allow_ldap_change-reset_pwd'] = "yes";
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Update</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- meta name="viewport" content="width=device-width, user-scalable=no" -->
<meta name="viewport" content="width=device-width, initial-scale=.9">
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: white;
   color: grey;
   text-align: center;
   font-size: 12px;
}
</style>
<style>
p.ex2 {
  margin-left: 8px;
}
</style>

<script type="text/javascript" src="../Login/jquery.js"></script>
<script type="text/javascript" src="../Login/jquery-ui.js"></script>
<script type="text/javascript" src="../Login/polyfiller.js"></script>

<!-- aPersona Client Discovery Script. This generates the aPersona authParam hidden variable. -->
<script type="text/javascript" src="../asm_api/sha1.js"></script>
<script type="text/javascript" src="../asm_api/apersona_v2.3.js"></script>
<!-- End aPersona integration section -->

<script>
  setTimeout(function(){
    document.getElementById('info-message').style.display = 'none';
    /* or
    var item = document.getElementById('info-message')
    item.parentNode.removeChild(item); 
    */
  }, 20000);
</script>

<link rel="stylesheet" type="text/css" href="../fusion.css">
<link rel="stylesheet" type="text/css" href="../style.css">
<link rel="stylesheet" type="text/css" href="../site.css">
</head>
<body style="background-color: rgb(255,255,255); background-image: none; margin: 0px;" class="nof-centerBody">
  <div align="center">
    <table border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td width="3022">
                <table id="Table7" border="0" cellspacing="0" cellpadding="0" width="100%" style="background-color: rgb(245,243,241); height: 54px;">
                  <tr style="height: 54px;">
                    <td width="43" id="Cell288"></td>
                    <td width="2801" id="Cell289">
                      <p class="ex2" style="margin-bottom: 0px;"><a href="../Reset-Password/reset.php"><img id="Picture26" height="40" width="201" src="../branding/logo.png" vspace="0" hspace="0" align="top" border="0" alt="logo" title="logo"></p>
                    </td>
                    <td width="96" id="Cell309">
                    </td>
                    <td width="18" id="Cell310"></td>
                    <td width="64" style="background-color: rgb(245,243,241);" id="Cell311">
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td height="9"></td>
            </tr>
            <tr valign="top" align="left">
              <td width="3023">
                <table id="Table6" border="0" cellspacing="2" cellpadding="2" width="100%" style="height: 106px;">
                  <tr style="height: 110px;">
                    <td width="41" id="Cell150">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                    <td width="98%" id="Cell152">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td align="center">
                            <table id="Table11" border="0" cellspacing="0" cellpadding="0" width="11" style="height: 85px;">
                              <tr style="height: 34px;">
                                <td width="9" id="Cell163">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td width="342" id="Cell290">
                                  <p style="margin-bottom: 0px;"><b><span style="font-size: 28px; font-weight: bold;"><?php echo $_SESSION['company_name'];?></span></b></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell164">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td align="left" id="Cell291">
                                  <p style="margin-bottom: 0px;"><b><span style="font-weight: bold;">&nbsp;<?php echo $_SESSION['app_title'];?></span></b></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell165">
                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td align="center"><img id="Picture25" height="6" width="9" src="../branding/450sp.png" border="0" alt="450sp" title="450sp"></td>
                                    </tr>
                                  </table>
                                </td>
                                <td id="Cell292">
                                  <p style="margin-bottom: 0px;"><img id="Picture18" height="7" width="342" src="../branding/450sp.png" vspace="0" hspace="0" align="middle" border="0" alt="450sp" title="450sp">&nbsp;</p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell166">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td align="left" id="Cell301">
                                  <p style="margin-bottom: 0px;"><i>&nbsp;<?php echo $_SESSION['update_instructions'];?></i></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell296">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td id="Cell297">
                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td align="left"><img id="Picture31" height="8" width="342" src="../branding/450spWtLGr.png" border="0" alt="450spWtLGr" title="450spWtLGr"></td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td width="25" id="Cell153">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td width="3023">
                <table id="Table9" border="0" cellspacing="0" cellpadding="0" width="100%" style="height: 253px;">
                  <tr style="height: auto;">
                    <td width="41" id="Cell302">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                    <td width="98%" id="Cell303">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td align="center">

                            <form name="asmIDMgmtUpdate" method="post" target='_self' action='../scripts/ldap_change-reset_pwd.php'>

				<!-- aPersona hidden variable authParam passed as a post variable. -->
				<input type="hidden" id="authParam" name="authParam"/>
				<!-- End aPersona integration section -->

                              <table border="0" cellspacing="0" cellpadding="0">
                                <tr valign="top" align="left">
                                  <td width="351">
                                    <table id="Table10" border="0" cellspacing="0" cellpadding="0" width="70%" style="height: 269px;">
                                      <tr style="height: 8px;">
                                        <td width="9" id="Cell313"></td>
                                        <td width="342" id="Cell312"></td>
                                      </tr>



<!-- New Information Section -->

                                      <tr style="height: 20px;">
                                        <td id="Cell170"></td>
                                        <td valign="middle" style="background-color: rgb(255,255,255);" id="NewInfoTitleCell">
                                          <p style="text-align: left; margin-bottom: 0px;">&nbsp; <b><span style="font-weight: bold;">Type in your <u>new</u>  <?php echo $_SESSION['update_method']; ?>:</span></b></p>
                                        </td>
                                      </tr>
                                      <tr style="height: 25px;">
                                        <td id="Cell171"></td>
                                        <td valign="middle" style="background-color: rgb(255,255,255);" id="NewInfoCell">
                                          <p style="margin-bottom: 0px;"><input type="<?php echo $_SESSION['input_type']; ?>" id="New" name="new" required class="field required" required="true" size="44" maxlength="250" style="font-size: 20px; white-space: pre; width: 348px;" placeholder="<?php echo $_SESSION['new_placeholder']; ?>"></p>
                                        </td>
                                      </tr>
                                      <tr style="height: 8px;">
                                        <td id="Cell172"></td>
                                        <td id="Cell305"></td>
                                      </tr>

<!-- New Information 2 Section -->
                                      <tr style="height: 21px;">
                                        <td id="Cell173"></td>
                                        <td valign="middle" id="NewInfo2TitleCell">
                                          <p style="text-align: left; margin-bottom: 0px;">&nbsp;<b><span style="font-weight: bold;">Type in your <u>new</u>  <?php echo $_SESSION['update_method']; ?>&nbsp;again:</span></b></p>
                                        </td>
                                      </tr>
                                      <tr style="height: 22px;">
                                        <td id="Cell174"></td>
                                        <td valign="middle" id="NewInfo2Cell">
                                          <p style="text-align: left; margin-bottom: 0px;"><input type="<?php echo $_SESSION['input_type']; ?>" id="New2" name="new2" required class="field required" required="true" size="44" maxlength="250" style="font-size: 20px; white-space: pre; width: 348px;" placeholder="<?php echo $_SESSION['new_placeholder']; ?>"></p>
                                        </td>
                                      </tr>
                                      <tr style="height: 5px;">
                                        <td id="Cell175"></td>
                                        <td id="Cell306"></td>
                                      </tr>



<!-- Update Button Section -->



                                      <tr style="height: 52px;">
                                        <td id="Cell177"></td>
                                        <td valign="middle" id="UpdateButtonCell">
                                          <p style="text-align: left; margin-bottom: 0px;"><b><span style="font-weight: bold;"></span>
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                              <tr>
                                                <td align="center"><input type="image" id="ResetButton" name="ResetButton" value="Reset" src="../branding/reset_button.png" style="height: 40px; width: 95px;">&nbsp;&nbsp;<a href="../Reset-Password/reset.php"><img border="0" alt="cancel_button" src="../branding/cancel_button.png" width="95" height="40"></td>
                                              </tr>
                                            </table>
                                            </b></td>
                                        </tr>
                                        <tr style="height: 9px;">
                                          <td id="Cell178"></td>
                                          <td id="Cell307"></td>
                                        </tr>
                                        <tr style="height: 19px;">
                                          <td id="Cell179"></td>
                                          <td valign="middle" id="Cell287">
                                            <p style="margin-bottom: 0px;"><b><p style="margin-bottom: 0px;"><p id="info-message"><span style="font-size: 14px; color: rgb(159,41,41);"><?php if(strpos($_GET['error'],"<?php")  ||  strpos($_GET['msg'],"<?php")) {header('Location: ../Reset-Password/reset.php?error=Application violation.'); exit();} ?><?php $error = $_GET['error']; echo($error);?><span style="font-size: 14px; color: rgb(46,139,87);"><?php $msg = $_GET['msg']; echo($msg);?></span></p><b>
                                          </td>
                                        </tr>
                                        <tr style="height: 35px;">
                                          <td id="Cell180">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                              <tr>
                                                <td align="center"><img id="Picture24" height="6" width="9" src="../branding/450sp.png" border="0" alt="450sp" title="450sp"></td>
                                              </tr>
                                            </table>
                                          </td>
                                          <td valign="middle" id="Cell162">
                                            <p style="margin-bottom: 0px;"><img id="Picture17" height="7" width="342" src="../branding/450sp.png" vspace="0" hspace="0" align="middle" border="0" alt="450sp" title="450sp"></p>
                                          </td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                                </table>
                              </form>
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td width="25" id="Cell308">
                        <p style="margin-bottom: 0px;">&nbsp;</p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <div class="footer">
  <p><?php echo $_SESSION['footer']; ?></p>
</div>

          </td>
        </tr>
      </table>
    </div>
  </body>
  </html>
   