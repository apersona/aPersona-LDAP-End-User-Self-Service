<?php
# When the login pages loads, we want to ensure all sessions are cleared.
session_start(); # Starts the session
IF ($_SESSION['allow_verify_page'] != "yes"){header('Location: ../Login/index.php?error=aP Verify Not Allowed.'); exit();}
$_SESSION['allow_verify_page'] = "no";
$_SESSION['allow_ap_api_resend'] = "yes";
$_SESSION['allow_ap_api_otp_send'] = "yes";
$_SESSION['allow_skip_otp_method'] = "yes";
$_SESSION['allow_ss_verify_login'] = "yes";
# echo $_SERVER['HTTP_HOST'];
# Run client IP discovery
 $_SESSION['allow_ip_discovery'] = "yes";
 include_once('../asm_api/ap_ip_discovery.php');
 if ( $_SESSION['initial_ip']!=$client_ipaddress) {
	header('Location: ../Login/index.php?error=Change in operating environment.'); 
	exit();
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Verify</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- meta name="viewport" content="width=device-width, user-scalable=no" -->
<meta name="viewport" content="width=device-width, initial-scale=.9">
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: white;
   color: grey;
   text-align: center;
   font-size: 12px;
}
</style>
<style>
p.ex2 {
  margin-left: 8px;
}
</style>

<script type="text/javascript" src="../Login/jquery.js"></script>
<script type="text/javascript" src="../Login/jquery-ui.js"></script>
<script type="text/javascript" src="../Login/polyfiller.js"></script>

<script>
  setTimeout(function(){
    document.getElementById('info-message').style.display = 'none';
    /* or
    var item = document.getElementById('info-message')
    item.parentNode.removeChild(item); 
    */
  }, 12000);
</script>


<link rel="stylesheet" type="text/css" href="../fusion.css">
<link rel="stylesheet" type="text/css" href="../style.css">
<link rel="stylesheet" type="text/css" href="../site.css">
</head>
<body style="background-color: rgb(255,255,255); background-image: none; margin: 0px;" class="nof-centerBody">
  <div align="center">
    <table border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td width="3022">
                <table id="Table7" border="0" cellspacing="0" cellpadding="0" width="100%" style="background-color: rgb(245,243,241); height: 54px;">
                  <tr style="height: 54px;">
                    <td width="43" id="Cell288"></td>
                    <td width="2801" id="Cell289">
                      <p class="ex2" style="margin-bottom: 0px;"><a href="../Login/index.php"><img id="Picture26" height="40" width="201" src="../branding/logo.png" vspace="0" hspace="0" align="top" border="0" alt="logo" title="logo"></p>
                    </td>
                    <td width="96" id="Cell309">
                    </td>
                    <td width="18" id="Cell310"></td>
                    <td width="64" id="Cell311"> 
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td height="9"></td>
            </tr>
            <tr valign="top" align="left">
              <td width="3023">
                <table id="Table6" border="0" cellspacing="2" cellpadding="2" width="100%" style="height: 106px;">
                  <tr style="height: 110px;">
                    <td width="41" id="Cell150">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                    <td width="98%" id="Cell152">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td align="center">
                            <table id="Table11" border="0" cellspacing="0" cellpadding="0" width="11" style="height: 85px;">
                              <tr style="height: 34px;">
                                <td width="9" id="Cell163">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td width="342" id="Cell290">
                                  <p style="margin-bottom: 0px;"><b><span style="font-size: 28px; font-weight: bold;"><?php echo $_SESSION['company_name'];?></span></b></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell164">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td align="left" id="Cell291">
                                  <p style="margin-bottom: 0px;"><b><span style="font-weight: bold;">&nbsp;<?php echo $_SESSION['app_title'];?></span></b></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell165">
                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td align="center"><img id="Picture25" height="6" width="9" src="../branding/450sp.png" border="0" alt="450sp" title="450sp"></td>
                                    </tr>
                                  </table>
                                </td>
                                <td id="Cell292">
                                  <p style="margin-bottom: 0px;"><img id="Picture18" height="7" width="342" src="../branding/450sp.png" vspace="0" hspace="0" align="middle" border="0" alt="450sp" title="450sp">&nbsp;</p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell166">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td align="left" id="Cell301">
                                  <p style="margin-bottom: 0px;"><i>&nbsp;<?php echo $_SESSION['verify_page_notification'];?></i></p>
                                </td>
                              </tr>
                              <tr style="height: 19px;">
                                <td id="Cell296">
                                  <p style="margin-bottom: 0px;">&nbsp;</p>
                                </td>
                                <td id="Cell297">
                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td align="left"><img id="Picture31" height="8" width="342" src="../branding/450spWtLGr.png" border="0" alt="450spWtLGr" title="450spWtLGr"></td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td width="25" id="Cell153">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <table border="0" cellspacing="0" cellpadding="0">
            <tr valign="top" align="left">
              <td width="3023">
                <table id="Table9" border="0" cellspacing="0" cellpadding="0" width="100%" style="height: 150px;">
                  <tr style="height: auto;">
                    <td width="41" id="Cell302">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                    <td width="98%" id="Cell303">
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td align="center">
                            <form name="asmIDMgmtVerify" method="post" target='_self' action='../scripts/ap_api_otp_send.php'>
                              <table border="0" cellspacing="0" cellpadding="0">
                                <tr valign="top" align="left">
                                  <td width="351">
                                    <table id="Table10" border="0" cellspacing="0" cellpadding="0" width="100%" style="height: 102px;">
                                      <tr style="height: 57px;">
                                        <td width="9" id="Cell315">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="2" id="Cell314">
                                          <p style="text-align: left; margin-bottom: 0px;"><b><span style="font-weight: bold;"></span></b><?php echo $_SESSION['verify_page_instructions'];?></p>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell167">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="2" id="AltEmailTitleCell">
                                          <p style="text-align: left; margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                      </tr>
                                      <tr style="height: 26px;">
                                        <td id="Cell175">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td valign="middle" width="112" id="Cell306">
                                          <p style="margin-bottom: 0px;"><input type="tel" id="IdentityCodeField" name="IdentityCode" style="font-size: 20px; white-space: pre; width: 100px;" placeholder="ID Code"></p>
                                        </td>
                                        <td valign="middle" width="230" id="Cell312">
                                          <p style="margin-bottom: 0px;">&nbsp; <a onclick="processing()" href="../asm_api/ap_api_resend.php"><img src="../branding/resend_button.png" height="25" width="110"></a></p>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell177">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="2" id="not_used_1">
                                          <p style="text-align: left; margin-bottom: 0px;"><b><span style="font-weight: bold;"></span></b>&nbsp;</p>
                                        </td>
                                      </tr>

                                     <tr style="height: 27px;">
                                        <td id="Cell178">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="2" valign="middle" id="Cell307">
                                          <p style="margin-bottom: 0px;"><input type="image" id="VerifyButton" onclick="processing()" name="VerifyButton" value="Verify" src="../branding/verify_button.png"  style="height: 40px; width: 95px;">&nbsp; &nbsp; <a onclick="processing()" href="../scripts/skip_otp_method.php"><?php if($_SESSION['hide_skip_on_verify_page']!="yes") echo '<img src="../branding/skip_button.png" height="25" width="180">'; ?></a></p>
<p id="processing" ></p><script> function processing() {document.getElementById("processing").innerHTML = "<br><br>Processing...stand-by."; } </script>
                                        </td>
                                      </tr>
                                      <tr style="height: 19px;">
                                        <td id="Cell179">
                                          <p style="margin-bottom: 0px;">&nbsp;</p>
                                        </td>
                                        <td colspan="2" valign="middle" id="Cell287">
                                          <p style="margin-bottom: 0px;"><b><p style="margin-bottom: 0px;"><p id="info-message"><span style="font-size: 14px; color: rgb(159,41,41);"><?php if(strpos($_GET['error'],"<?php")  ||  strpos($_GET['msg'],"<?php")) {header('Location: ../Login/index.php?error=Application violation.'); exit();} ?><?php $error = $_GET['error']; echo($error);?><span style="font-size: 14px; color: rgb(46,139,87);"><?php $msg = $_GET['msg']; echo($msg."<br>");   if($_SESSION['ap_otpm']=="e"  || $_SESSION['ap_otpm']=="ae") echo"Identity codes sent to email addresses may take a minuite to arrive. Also check your spam folder if you do not see it in 1 minute.";             ?></span></p><b>
                                        </td>
                                      </tr>

                                      <tr style="height: 19px;">
                                        <td id="Cell180">
                                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                            <tr>
                                              <td align="center"><img id="Picture24" height="6" width="9" src="../branding/450sp.png" border="0" alt="450sp" title="450sp"></td>
                                            </tr>
                                          </table>
                                        </td>
                                        <td colspan="2" valign="middle" id="Cell162">
                                          <p style="margin-bottom: 0px;"><img id="Picture17" height="7" width="342" src="../branding/450sp.png" vspace="0" hspace="0" align="middle" border="0" alt="450sp" title="450sp">&nbsp;</p>
                                        </td>
                                      </tr>
                                    </table>
                                  </td>
                                </tr>
                              </table>
                            </form>
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td width="25" id="Cell308">
                      <p style="margin-bottom: 0px;">&nbsp;</p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          <script type="text/javascript">
          //Begin Webshims
//$.webshims.debug = true;
//$.webshims.activeLang("en");
//$.webshims.setOptions('forms-ext', {replaceUI: false, types: 'datetime-local range date time number month color', widgets: {popover: {appendTo: 'body'}}});
//$.webshims.polyfill('forms forms-ext');
//End Webshims


          </script>
          <div class="footer">
  <p><?php echo $_SESSION['footer']; ?></p>
</div>  
 </tr>
    </table>
  </div>
</body>
</html>
 